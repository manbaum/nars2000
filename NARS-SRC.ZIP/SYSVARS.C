//' $Header$

//***************************************************************************
//  NARS2000 -- System Variable Routines
//***************************************************************************

#pragma pack (1)
#define STRICT
#include <windows.h>

#include "main.h"
#include "aplerrors.h"
#include "datatype.h"
#include "resdebug.h"
#include "symtab.h"
#include "tokens.h"
#include "Unicode.h"

// Include prototypes unless prototyping
#ifndef PROTO
#include "compro.h"
#endif


// Global values of system variables so we can use them
//   without having to access the actual system var

HGLOBAL  hGlbALX,           // []ALX
         hGlbELX,           // []ELX
         hGlbLX,            // []LX
         hGlbSA,            // []SA
         hGlbWSID;          // []WSID
APLFLOAT fCT;               // []CT
APLBOOL  bDF,               // []DF
         bIO;               // []IO
APLINT   uPP,               // []PP
         uPW,               // []PW
         uRL;               // []RL
char     cPR;               // []PR


typedef struct tagSYSNAME
{
    LPWCHAR lpwszName;  // The name
    UINT    uValence;   // For system functions, Niladic(0), Monadic(1), Dyadic(2), Monadic/Dyadic(3)
    BOOL    bSysVar;    // Izit a system variable (TRUE) or function (FLASE)?  If TRUE, uValence is ignored
} SYSNAME, *LPSYSNAME;

SYSNAME aSystemNames[] =
{ // Name                Valence    Var?
    {WS_UCS2_QUAD          ,    9,      TRUE },     //  0:  Output
    {WS_UCS2_QUOTEQUAD     ,    9,      TRUE },     //  1:  Character Output
    {WS_UCS2_QUAD L"alx"   ,    9,      TRUE },     //  2:  Attention Latent Expression
    {WS_UCS2_QUAD L"ct"    ,    9,      TRUE },     //  3:  Comparison Tolerance
    {WS_UCS2_QUAD L"df"    ,    9,      TRUE },     //  4:  Display Format
    {WS_UCS2_QUAD L"elx"   ,    9,      TRUE },     //  5:  Error Latent Expression
    {WS_UCS2_QUAD L"io"    ,    9,      TRUE },     //  6:  Index Origin
    {WS_UCS2_QUAD L"lx"    ,    9,      TRUE },     //  7:  Latent Expression
    {WS_UCS2_QUAD L"pp"    ,    9,      TRUE },     //  8:  Printing Precision
    {WS_UCS2_QUAD L"pr"    ,    9,      TRUE },     //  9:  Prompt Replacement
    {WS_UCS2_QUAD L"pw"    ,    9,      TRUE },     // 10:  Printing Width
    {WS_UCS2_QUAD L"rl"    ,    9,      TRUE },     // 11:  Random Link
    {WS_UCS2_QUAD L"sa"    ,    9,      TRUE },     // 12:  Stop Action
    {WS_UCS2_QUAD L"wsid"  ,    9,      TRUE },     // 13:  Workspace Identifier

    {WS_UCS2_QUAD L"ai"    ,    0,      FALSE},     // Accounting Information
    {WS_UCS2_QUAD L"av"    ,    0,      FALSE},     // Atomic Vector
    {WS_UCS2_QUAD L"dm"    ,    0,      FALSE},     // Diagnostic Message
    {WS_UCS2_QUAD L"lc"    ,    0,      FALSE},     // Line Counter
    {WS_UCS2_QUAD L"si"    ,    0,      FALSE},     // State Indicator
    {WS_UCS2_QUAD L"sinl"  ,    0,      FALSE},     // State Indicator w/Name List
    {WS_UCS2_QUAD L"ts"    ,    0,      FALSE},     // Time Stamp
    {WS_UCS2_QUAD L"sysid" ,    0,      FALSE},     // System Identifier
    {WS_UCS2_QUAD L"sysver",    0,      FALSE},     // System Version
    {WS_UCS2_QUAD L"tc"    ,    0,      FALSE},     // Terminal Control Characters
    {WS_UCS2_QUAD L"tcbel" ,    0,      FALSE},     // Terminal Control Character, Bell
    {WS_UCS2_QUAD L"tcbs"  ,    0,      FALSE},     // Terminal Control Character, Backspace
    {WS_UCS2_QUAD L"tcdel" ,    0,      FALSE},     // Terminal Control Character, Delete
    {WS_UCS2_QUAD L"tcesc" ,    0,      FALSE},     // Terminal Control Character, Escape
    {WS_UCS2_QUAD L"tcff"  ,    0,      FALSE},     // Terminal Control Character, Form Feed
    {WS_UCS2_QUAD L"tcht"  ,    0,      FALSE},     // Terminal Control Character, Horizontal Tab
    {WS_UCS2_QUAD L"tclf"  ,    0,      FALSE},     // Terminal Control Character, Line Feed
    {WS_UCS2_QUAD L"tcnl"  ,    0,      FALSE},     // Terminal Control Character, New Line
    {WS_UCS2_QUAD L"tcnul" ,    0,      FALSE},     // Terminal Control Character, Null
    {WS_UCS2_QUAD L"wa"    ,    0,      FALSE},     // Workspace Available

    {WS_UCS2_QUAD L"cr"    ,    1,      FALSE},     // Canonical Representation
    {WS_UCS2_QUAD L"crl"   ,    1,      FALSE},     // Canonical Representation, Line
    {WS_UCS2_QUAD L"crlpc" ,    1,      FALSE},     // Canonical Representation, Public Comment
    {WS_UCS2_QUAD L"def"   ,    1,      FALSE},     // Define Function
    {WS_UCS2_QUAD L"defl"  ,    1,      FALSE},     // Define Function Line
    {WS_UCS2_QUAD L"dl"    ,    1,      FALSE},     // Delay Execution
    {WS_UCS2_QUAD L"erase" ,    1,      FALSE},     // Erase Names
    {WS_UCS2_QUAD L"error" ,    1,      FALSE},     // Signal Error
    {WS_UCS2_QUAD L"ex"    ,    1,      FALSE},     // Erase Names
    {WS_UCS2_QUAD L"fi"    ,    1,      FALSE},     // Format Items
    {WS_UCS2_QUAD L"fx"    ,    1,      FALSE},     // Fix Function
    {WS_UCS2_QUAD L"idloc" ,    1,      FALSE},     // Identifier Localization
    {WS_UCS2_QUAD L"lock"  ,    1,      FALSE},     // Lock Functions
    {WS_UCS2_QUAD L"mf"    ,    1,      FALSE},     // Monitor Function
    {WS_UCS2_QUAD L"nc"    ,    1,      FALSE},     // Name Classification
    {WS_UCS2_QUAD L"size"  ,    1,      FALSE},     // Size of an object
    {WS_UCS2_QUAD L"vi"    ,    1,      FALSE},     // Verify Items
    {WS_UCS2_QUAD L"vr"    ,    1,      FALSE},     // Vector Representation of a Function

    {WS_UCS2_QUAD L"fmt"   ,    2,      FALSE},     // Format
    {WS_UCS2_QUAD L"ss"    ,    2,      FALSE},     // Search String

    {WS_UCS2_QUAD L"call"  ,    3,      FALSE},     // Call Assembler Code
    {WS_UCS2_QUAD L"idlist",    3,      FALSE},     // Identifier List
    {WS_UCS2_QUAD L"nl"    ,    3,      FALSE},     // Name List
    {WS_UCS2_QUAD L"stop"  ,    3,      FALSE},     // Manage Stop Points
    {WS_UCS2_QUAD L"trace" ,    3,      FALSE},     // Manage Trace Points

    // ***FIXME*** Add more entries
};


//***************************************************************************
//  SymTabAppendSysName_EM
//
//  Append a system name to the symbol table
//***************************************************************************

LPSYMENTRY SymTabAppendSysName_EM
    (LPSYSNAME lpSysName)

{
    STFLAGS stFlags = {0};

    // Set the flags of the entry we're appending
    if (lpSysName->bSysVar)
    {
        stFlags.SysVar =
        stFlags.Value  = 1;
    } else
    {
        if (lpSysName->uValence EQ 0)
            stFlags.SysFn0 = 1;
        else
            stFlags.SysFn12 = 1;
    } // End IF/ELSE

    stFlags.SysName =
    stFlags.Perm    =
    stFlags.Nocase  =
    stFlags.Inuse   = 1;

    return SymTabAppendNewName_EM (lpSysName->lpwszName, &stFlags);
} // End SymTabAppendSysName_EM


//***************************************************************************
//  AppendSystemNames_EM
//
//  Append all system names to the symbol table
//***************************************************************************

BOOL AppendSystemNames_EM (void)

{
    int i;

    Assert (HshTabFrisk ());

    // Append all system names
    for (i = 0; i < sizeof (aSystemNames) / sizeof (aSystemNames[0]); i++)
    if (!SymTabAppendSysName_EM (&aSystemNames[i]))
        return FALSE;

    Assert (HshTabFrisk ());

    return TRUE;
} // End AppendSystemNames_EM


//***************************************************************************
//  AssignCharVector_EM
//
//  Assign a character vector to a name
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- AssignCharVector_EM"
#else
#define APPEND_NAME
#endif

void AssignCharVector_EM
    (LPWCHAR lpwszName,
     LPWCHAR lpwszString,
     UINT    SysVarValid,
     LPVOID  lpGlbVal)

{
    LPSYMENTRY lpSymEntryDest;
    STFLAGS    stFlags = {0};
    int        iStringLen;
    HGLOBAL    hGlb;

    // Lookup the name in the symbol table
    // SymTabLookupName sets the .SysName or .UsrName flag,
    //   and the .Inuse flag
    lpSymEntryDest = SymTabLookupName (lpwszName, &stFlags);
    if (!lpSymEntryDest)        // It's not found???
    {
        ErrorMessageIndirect (ERRMSG_PROGRAM_ERROR APPEND_NAME);

        DbgStop ();             // We should never get here

        return;
    } // End IF

    // Get the string length (exluding the terminating zero)
    iStringLen = lstrlenW (lpwszString);

    // Allocate global memory for the array header,
    //   one dimension (it's a vector), and the string
    //   excluding the terminating zero.
    hGlb = DbgGlobalAlloc (GHND,
                           sizeof (VARARRAY_HEADER)
                         + sizeof (APLDIM) * 1
                         + iStringLen * sizeof (WCHAR));
    if (!hGlb)
    {
        ErrorMessageIndirect (ERRMSG_WS_FULL APPEND_NAME);

        return;
    } else
    {
        LPWCHAR lpwsz;

        // Lock the handle, setup the header, and copy
        //   the string to the global memory
        lpwsz = MyGlobalLock (hGlb);

#define lpHeader    ((LPVARARRAY_HEADER) lpwsz)

        lpHeader->Sign.ature = VARARRAY_HEADER_SIGNATURE;
        lpHeader->ArrType    = ARRAY_CHAR;
////////lpHeader->Perm       = 0;
        lpHeader->SysVar     = 1;
        lpHeader->RefCnt     = 1;
        lpHeader->NELM       = iStringLen;
        lpHeader->Rank       = 1;

#undef  lpHeader

        *VarArrayBaseToDim (lpwsz) = iStringLen;
        CopyMemory (VarArrayBaseToData (lpwsz, 1),
                    lpwszString,
                    iStringLen * sizeof (APLCHAR));
        MyGlobalUnlock (hGlb); lpwsz = NULL;

        // Save in global ptr
        *((HGLOBAL *) lpGlbVal) = hGlb;
    } // End IF/ELSE

    // Save the global memory ptr
    lpSymEntryDest->stData.stGlbData = MakeGlbTypeGlb (hGlb);

    // Save the flags
    stFlags.SysVarValid = SysVarValid;
    *(UINT *)&lpSymEntryDest->stFlags |= *(UINT *)&stFlags;
} // End AssignCharVector_EM
#undef  APPEND_NAME


//***************************************************************************
//  AssignRealScalar_EM
//
//  Assign a real number scalar to a name
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- AssignRealScalar_EM"
#else
#define APPEND_NAME
#endif

void AssignRealScalar_EM
    (LPWCHAR  lpwszName,
     APLFLOAT fFloat,
     UINT     SysVarValid,
     LPVOID  lpGlbVal)

{
    LPSYMENTRY lpSymEntryDest;
    STFLAGS    stFlags = {0};

    // Lookup the name in the symbol table
    // SymTabLookupName sets the .SysName or .UsrName flag,
    //   and the .Inuse flag
    lpSymEntryDest = SymTabLookupName (lpwszName, &stFlags);
    if (!lpSymEntryDest)        // It's not found???
    {
        ErrorMessageIndirect (ERRMSG_PROGRAM_ERROR APPEND_NAME);

        DbgStop ();             // We should never get here

        return;
    } // End IF

    // Save the constant
    *((LPAPLFLOAT) lpGlbVal) = lpSymEntryDest->stData.stFloat = fFloat;

    // Mark as immediate floating point constant
    stFlags.Imm     = 1;
    stFlags.ImmType = IMMTYPE_FLOAT;

    // Save the flags
    stFlags.SysVarValid = SysVarValid;
    *(UINT *)&lpSymEntryDest->stFlags |= *(UINT *)&stFlags;
} // End AssignRealScalar_EM
#undef  APPEND_NAME


//***************************************************************************
//  AssignBoolScalar
//
//  Assign an Boolean scalar to a name
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- AssignBoolScalar_EM"
#else
#define APPEND_NAME
#endif

void AssignBoolScalar_EM
    (LPWCHAR lpwszName,
     APLBOOL aplBoolean,
     UINT    SysVarValid,
     LPVOID  lpGlbVal)

{
    LPSYMENTRY lpSymEntryDest;
    STFLAGS    stFlags = {0};

    // Lookup the name in the symbol table
    // SymTabLookupName sets the .SysName or .UsrName flag,
    //   and the .Inuse flag
    lpSymEntryDest = SymTabLookupName (lpwszName, &stFlags);
    if (!lpSymEntryDest)        // It's not found???
    {
        ErrorMessageIndirect (ERRMSG_PROGRAM_ERROR APPEND_NAME);

        DbgStop ();             // We should never get here

        return;
    } // End IF

    // Save the constant
    *((LPAPLBOOL) lpGlbVal) = lpSymEntryDest->stData.stBoolean = aplBoolean;

    // Mark as immediate Boolean constant
    stFlags.Imm     = 1;
    stFlags.ImmType = IMMTYPE_BOOL;

    // Save the flags
    stFlags.SysVarValid = SysVarValid;
    *(UINT *)&lpSymEntryDest->stFlags |= *(UINT *)&stFlags;
} // End AssignBoolScalar_EM
#undef  APPEND_NAME


//***************************************************************************
//  AssignIntScalar_EM
//
//  Assign an integer scalar to a name
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- AssignIntScalar_EM"
#else
#define APPEND_NAME
#endif

void AssignIntScalar_EM
    (LPWCHAR lpwszName,
     APLINT  aplInteger,
     UINT    SysVarValid,
     LPVOID  lpGlbVal)

{
    LPSYMENTRY lpSymEntryDest;
    STFLAGS    stFlags = {0};

    // Lookup the name in the symbol table
    // SymTabLookupName sets the .SysName or .UsrName flag,
    //   and the .Inuse flag
    lpSymEntryDest = SymTabLookupName (lpwszName, &stFlags);
    if (!lpSymEntryDest)        // It's not found???
    {
        ErrorMessageIndirect (ERRMSG_PROGRAM_ERROR APPEND_NAME);

        DbgStop ();             // We should never get here

        return;
    } // End IF

    // Save the constant
    *((LPAPLINT) lpGlbVal) = lpSymEntryDest->stData.stInteger = aplInteger;

    // Mark as immediate Integer constant
    stFlags.Imm     = 1;
    stFlags.ImmType = IMMTYPE_INT;

    // Save the flags
    stFlags.SysVarValid = SysVarValid;
    *(UINT *)&lpSymEntryDest->stFlags |= *(UINT *)&stFlags;
} // End AssignIntScalar_EM
#undef  APPEND_NAME


//***************************************************************************
//  AssignCharScalar_EM
//
//  Assign a character scalar to a name
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- AssignCharScalar_EM"
#else
#define APPEND_NAME
#endif

void AssignCharScalar_EM
    (LPWCHAR lpwszName,
     WCHAR   aplChar,
     UINT    SysVarValid,
     LPVOID  lpGlbVal)

{
    LPSYMENTRY lpSymEntryDest;
    STFLAGS    stFlags = {0};

    // Lookup the name in the symbol table
    // SymTabLookupName sets the .SysName or .UsrName flag,
    //   and the .Inuse flag
    lpSymEntryDest = SymTabLookupName (lpwszName, &stFlags);
    if (!lpSymEntryDest)        // It's not found???
    {
        ErrorMessageIndirect (ERRMSG_PROGRAM_ERROR APPEND_NAME);

        DbgStop ();             // We should never get here

        return;
    } // End IF

    // Save the constant
    *((LPAPLCHAR) lpGlbVal) = lpSymEntryDest->stData.stChar = aplChar;

    // Mark as immediate Character constant
    stFlags.Imm     = 1;
    stFlags.ImmType = IMMTYPE_CHAR;

    // Save the flags
    stFlags.SysVarValid = SysVarValid;
    *(UINT *)&lpSymEntryDest->stFlags |= *(UINT *)&stFlags;
} // End AssignCharScalar_EM
#undef  APPEND_NAME


//***************************************************************************
//  ValidateBoolean_EM
//
//  Validate a value about to be assigned to a Boolean system var.
//
//  We allow any numeric singleton whose value is 0 or 1.
//
//  The order of error checking is RANK, LENGTH, DOMAIN.
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- ValidateBoolean_EM"
#else
#define APPEND_NAME
#endif

BOOL ValidateBoolean_EM
    (LPTOKEN   lpToken,
     LPAPLBOOL lpbVal)

{
    LPVOID   lpMem, lpData;
    BOOL     bRet = TRUE;
    LPWCHAR  lpwErrMsg = ERRMSG_DOMAIN_ERROR APPEND_NAME;
    APLINT   aplInteger;

    // Split cases based upon the token type
    switch (lpToken->tkFlags.TknType)
    {
        case TKT_VARNAMED:
            DbgBrk ();      // ***TESTME***

            // tkData is an LPSYMENTRY
            Assert (GetPtrTypeDir (lpToken->tkData.lpVoid) EQ PTRTYPE_STCONST);

            if (!lpToken->tkData.lpSym->stFlags.Imm)
                break;      // Continue with HGLOBAL processing

            // Handle the immediate case

            // tkData is an LPSYMENTRY
            Assert (GetPtrTypeDir (lpToken->tkData.lpVoid) EQ PTRTYPE_STCONST);

            // Split case based upon the symbol table immediate type
            switch (lpToken->tkData.lpSym->stFlags.ImmType)
            {
                case IMMTYPE_BOOL:
                    *lpbVal = lpToken->tkData.lpSym->stData.stBoolean;

                    break;

                case IMMTYPE_INT:
                    // Because aplInteger is unsigned, we don't need
                    //   to test against zero explicitly.
                    bRet = (lpToken->tkData.lpSym->stData.stInteger <= 1);
                    if (bRet)
                        *lpbVal = (APLBOOL) (lpToken->tkData.lpSym->stData.stInteger);
                    break;

                case IMMTYPE_FLOAT:
                    // Convert the value to an integer using System CT
                    aplInteger = FloatToAplint_SCT (lpToken->tkData.lpSym->stData.stFloat,
                                                    &bRet);
                    // Because aplInteger is unsigned, we don't need
                    //   to test against zero explicitly.
                    bRet = bRet && (aplInteger <= 1);

                    if (bRet)
                        *lpbVal = (APLBOOL) aplInteger;
                    break;

                case IMMTYPE_CHAR:
                    bRet = FALSE;

                    break;
            } // End SWITCH

            if (!bRet)
                ErrorMessageIndirectToken (lpwErrMsg, lpToken);

            return bRet;

        case TKT_VARIMMED:
            // Split case based upon the token immediate type
            switch (lpToken->tkFlags.ImmType)
            {
                case IMMTYPE_BOOL:
                    *lpbVal = lpToken->tkData.tkBoolean;

                    break;

                case IMMTYPE_INT:
                    // Because aplInteger is unsigned, we don't need
                    //   to test against zero explicitly.
                    bRet = (lpToken->tkData.tkInteger <= 1);
                    if (bRet)
                        *lpbVal = (APLBOOL) (lpToken->tkData.tkInteger);
                    break;

                case IMMTYPE_FLOAT:
                    // Convert the value to an integer using System CT
                    aplInteger = FloatToAplint_SCT (lpToken->tkData.tkFloat,
                                                    &bRet);
                    // Because aplInteger is unsigned, we don't need
                    //   to test against zero explicitly.
                    bRet = bRet && (aplInteger <= 1);

                    if (bRet)
                        *lpbVal = (APLBOOL) aplInteger;
                    break;

                case IMMTYPE_CHAR:
                    bRet = FALSE;

                    break;
            } // End SWITCH

            if (!bRet)
                ErrorMessageIndirectToken (lpwErrMsg, lpToken);

            return bRet;

        case TKT_LIST:      // The tkData is an HGLOBAL of an array of HGLOBALs
            ErrorMessageIndirectToken (ERRMSG_SYNTAX_ERROR APPEND_NAME, lpToken);

            return FALSE;

        case TKT_STRING:    // tkData is an HGLOBAL of an array of ???
        case TKT_VARARRAY:  // tkData is an HGLOBAL of an array of ???
            break;          // Continue with HGLOBAL processing

        defstop
            return FALSE;
    } // End SWITCH

    DbgBrk ();              // ***TESTME***

    // tkData is a valid HGLOBAL variable array
    Assert (IsGlbTypeVarDir (lpToken->tkData.tkGlbData));

    // Lock the memory to get a ptr to it
    lpMem = MyGlobalLock (ClrPtrTypeDirGlb (lpToken->tkData.tkGlbData));

#define lpHeader    ((LPVARARRAY_HEADER) lpMem)

    // Skip over the header and dimensions to the data
    lpData = VarArrayBaseToData (lpHeader, lpHeader->Rank);

    // Check for singleton
    if (lpHeader->NELM NE 1)
    {
        if (lpHeader->Rank > 1)
            lpwErrMsg = ERRMSG_RANK_ERROR APPEND_NAME;
        else
            lpwErrMsg = ERRMSG_LENGTH_ERROR APPEND_NAME;
        bRet = FALSE;
    } else
    // Split cases based upon the array type
    switch (lpHeader->ArrType)
    {
        case ARRAY_BOOL:
            *lpbVal = *(LPAPLBOOL) lpData;

            break;

        case ARRAY_INT:
            // Because APLINT is unsigned, we don't need
            //   to compare against zero.
            bRet = ((*(LPAPLINT) lpData) <= 1);
            if (bRet)
                *lpbVal = (APLBOOL) (*(LPAPLINT) lpData);
            break;

        case ARRAY_CHAR:
        case ARRAY_HETERO:
        case ARRAY_NESTED:
            bRet = FALSE;

            break;

        case ARRAY_FLOAT:
            // Convert the value to an integer using System CT
            aplInteger = FloatToAplint_SCT (*(LPAPLFLOAT) lpData,
                                            &bRet);
            // Because aplInteger is unsigned, we don't need
            //   to test against zero explicitly.
            bRet = bRet && (aplInteger <= 1);

            if (bRet)
                *lpbVal = (APLBOOL) aplInteger;
            break;

        defstop
            break;
    } // End IF/ELSE/SWITCH

    MyGlobalUnlock (ClrPtrTypeDirGlb (lpToken->tkData.tkGlbData)); lpHeader= NULL;

    // Check for DOMAIN ERROR
    if (!bRet)
        ErrorMessageIndirectToken (lpwErrMsg, lpToken);
    return bRet;
#undef  lpHeader
} // End ValidateBoolean_EM
#undef  APPEND_NAME


//***************************************************************************
//  ValidateALX_EM
//
//  Validate a value about to be assigned to Quad-ALX
//***************************************************************************

BOOL ValidateALX_EM
    (LPTOKEN lpToken)

{


    return TRUE;
} // End ValidateALX_EM


//***************************************************************************
//  ValidateCT_EM
//
//  Validate a value about to be assigned to Quad-CT
//***************************************************************************

BOOL ValidateCT_EM
    (LPTOKEN lpToken)

{
    // ***FINISHME***


    return TRUE;
} // End ValidateCT_EM


//***************************************************************************
//  ValidateDF_EM
//
//  Validate a value about to be assigned to Quad-DF
//
//  We allow any numeric singleton whose value is 0 or 1.
//
//  The order of error checking is RANK, LENGTH, DOMAIN.
//***************************************************************************

BOOL ValidateDF_EM
    (LPTOKEN lpToken)

{
    return ValidateBoolean_EM (lpToken, &bDF);
} // End ValidateDF_EM


//***************************************************************************
//  ValidateELX_EM
//
//  Validate a value about to be assigned to Quad-ELX
//***************************************************************************

BOOL ValidateELX_EM
    (LPTOKEN lpToken)

{
    // ***FINISHME***


    return TRUE;
} // End ValidateELX_EM


//***************************************************************************
//  ValidateIO_EM
//
//  Validate a value about to be assigned to Quad-IO
//
//  We allow any numeric singleton whose value is 0 or 1.
//
//  The order of error checking is RANK, LENGTH, DOMAIN.
//***************************************************************************

BOOL ValidateIO_EM
    (LPTOKEN lpToken)

{
    return ValidateBoolean_EM (lpToken, &bIO);
} // End ValidateIO_EM


//***************************************************************************
//  ValidateLX_EM
//
//  Validate a value about to be assigned to Quad-LX
//***************************************************************************

BOOL ValidateLX_EM
    (LPTOKEN lpToken)

{
    // ***FINISHME***


    return TRUE;
} // End ValidateLX_EM


//***************************************************************************
//  ValidatePP_EM
//
//  Validate a value about to be assigned to Quad-PP
//***************************************************************************

BOOL ValidatePP_EM
    (LPTOKEN lpToken)

{
    // ***FINISHME***


    return TRUE;
} // End ValidatePP_EM


//***************************************************************************
//  ValidatePR_EM
//
//  Validate a value about to be assigned to Quad-PR
//***************************************************************************

BOOL ValidatePR_EM
    (LPTOKEN lpToken)

{
    // ***FINISHME***


    return TRUE;
} // End ValidatePR_EM


//***************************************************************************
//  ValidatePW_EM
//
//  Validate a value about to be assigned to Quad-PW
//***************************************************************************

BOOL ValidatePW_EM
    (LPTOKEN lpToken)

{
    // ***FINISHME***


    return TRUE;
} // End ValidatePW_EM


//***************************************************************************
//  ValidateRL_EM
//
//  Validate a value about to be assigned to Quad-RL
//***************************************************************************

BOOL ValidateRL_EM
    (LPTOKEN lpToken)

{
    // ***FINISHME***


    return TRUE;
} // End ValidateRL_EM


//***************************************************************************
//  ValidateSA_EM
//
//  Validate a value about to be assigned to Quad-SA
//***************************************************************************

BOOL ValidateSA_EM
    (LPTOKEN lpToken)

{
    // ***FINISHME***


    return TRUE;
} // End ValidateSA_EM


//***************************************************************************
//  ValidateWSID_EM
//
//  Validate a value about to be assigned to Quad-WSID
//***************************************************************************

BOOL ValidateWSID_EM
    (LPTOKEN lpToken)

{
    // ***FINISHME***


    return TRUE;
} // End ValidateWSID_EM


enum SYSVAR_VALID
{
    SYSVAR_VALID_ALX = 0,   //  0:
    SYSVAR_VALID_CT  ,      //  1:
    SYSVAR_VALID_DF  ,      //  2:
    SYSVAR_VALID_ELX ,      //  3:
    SYSVAR_VALID_IO  ,      //  4:
    SYSVAR_VALID_LX  ,      //  5:
    SYSVAR_VALID_PP  ,      //  6:
    SYSVAR_VALID_PR  ,      //  7:
    SYSVAR_VALID_PW  ,      //  8:
    SYSVAR_VALID_RL  ,      //  9:
    SYSVAR_VALID_SA  ,      // 10:
    SYSVAR_VALID_WSID,      // 11:

    SYSVAR_VALID_LENGTH     // 12: Length of the enum *MUST* be last
};

// Use as in:  (*aSysVarValid[1]) ();
BOOL (*aSysVarValid[SYSVAR_VALID_LENGTH]) (LPTOKEN);

//***************************************************************************
//  InitSystemVars
//
//  Initialize all system vars
//***************************************************************************

BOOL InitSystemVars
    (void)

{
    // Assign the validation routines
    aSysVarValid[SYSVAR_VALID_ALX ] = ValidateALX_EM ;
    aSysVarValid[SYSVAR_VALID_CT  ] = ValidateCT_EM  ;
    aSysVarValid[SYSVAR_VALID_DF  ] = ValidateDF_EM  ;
    aSysVarValid[SYSVAR_VALID_ELX ] = ValidateELX_EM ;
    aSysVarValid[SYSVAR_VALID_IO  ] = ValidateIO_EM  ;
    aSysVarValid[SYSVAR_VALID_LX  ] = ValidateLX_EM  ;
    aSysVarValid[SYSVAR_VALID_PP  ] = ValidatePP_EM  ;
    aSysVarValid[SYSVAR_VALID_PR  ] = ValidatePR_EM  ;
    aSysVarValid[SYSVAR_VALID_PW  ] = ValidatePW_EM  ;
    aSysVarValid[SYSVAR_VALID_RL  ] = ValidateRL_EM  ;
    aSysVarValid[SYSVAR_VALID_SA  ] = ValidateSA_EM  ;
    aSysVarValid[SYSVAR_VALID_WSID] = ValidateWSID_EM;

    // Assign default values to the system vars
    AssignCharVector_EM(WS_UCS2_QUAD L"alx" , WS_UCS2_QUAD L"DM", SYSVAR_VALID_ALX , &hGlbALX ); // Attention Latent Expression
    AssignRealScalar_EM(WS_UCS2_QUAD L"ct"  , 1E-13             , SYSVAR_VALID_CT  , &fCT     ); // Comparison Tolerance
    AssignBoolScalar_EM(WS_UCS2_QUAD L"df"  , 1                 , SYSVAR_VALID_DF  , &bDF     ); // Display Format
    AssignCharVector_EM(WS_UCS2_QUAD L"elx" , WS_UCS2_QUAD L"DM", SYSVAR_VALID_ELX , &hGlbELX ); // Error Latent Expression
    AssignBoolScalar_EM(WS_UCS2_QUAD L"io"  , 1                 , SYSVAR_VALID_IO  , &bIO     ); // Index Origin
    AssignCharVector_EM(WS_UCS2_QUAD L"lx"  , L""               , SYSVAR_VALID_LX  , &hGlbLX  ); // Latent Expression
    AssignIntScalar_EM (WS_UCS2_QUAD L"pp"  , 16                , SYSVAR_VALID_PP  , &uPP     ); // Printing Precision
    AssignCharScalar_EM(WS_UCS2_QUAD L"pr"  , L' '              , SYSVAR_VALID_PR  , &cPR     ); // Prompt Replacement
    AssignIntScalar_EM (WS_UCS2_QUAD L"pw"  , 80                , SYSVAR_VALID_PW  , &uPW     ); // Printing Width
    AssignIntScalar_EM (WS_UCS2_QUAD L"rl"  , 16807             , SYSVAR_VALID_RL  , &uRL     ); // Random Link
    AssignCharVector_EM(WS_UCS2_QUAD L"sa"  , L""               , SYSVAR_VALID_SA  , &hGlbSA  ); // Stop Action
    AssignCharVector_EM(WS_UCS2_QUAD L"wsid", L""               , SYSVAR_VALID_WSID, &hGlbWSID); // Workspace Identifier

    return TRUE;
} // End InitSystemVars


//***************************************************************************
//  End of File: sysvars.c
//***************************************************************************
