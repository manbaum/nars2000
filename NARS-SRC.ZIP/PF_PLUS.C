//***************************************************************************
//  NARS2000 -- Primitive Function -- Plus
//***************************************************************************

#pragma pack (1)
#define STRICT
#include <windows.h>

#include "main.h"
#include "aplerrors.h"
#include "datatype.h"
#include "resdebug.h"
#include "symtab.h"
#include "tokens.h"
#include "parse.h"

// Include prototypes unless prototyping
#ifndef PROTO
#include "compro.h"
#endif


//***************************************************************************
//  PrimFnPlus_EM
//
//  Primitive function for monadic and dyadic plus (conjugate and addition)
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- PrimFnPlus_EM"
#else
#define APPEND_NAME
#endif

LPYYSTYPE PrimFnPlus_EM
    (LPTOKEN lptkLftArg,
     LPTOKEN lptkFunc,
     LPTOKEN lptkRhtArg,
     LPTOKEN lptkAxis)

{
    // Ensure not an overflow function
    Assert (lptkFunc->tkData.tkChar EQ '+');

    // Split cases based upon monadic or dyadic
    if (lptkLftArg EQ NULL)
        return PrimFnMonPlus_EM             (lptkFunc, lptkRhtArg, lptkAxis);
    else
        return PrimFnDydPlus_EM (lptkLftArg, lptkFunc, lptkRhtArg, lptkAxis);
} // End PrimFnPlus_EM
#undef  APPEND_NAME


//***************************************************************************
//  PrimFnMonPlus_EM
//
//  Primitive function for monadic plus (conjugate)
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- PrimFnMonPlus_EM"
#else
#define APPEND_NAME
#endif

LPYYSTYPE PrimFnMonPlus_EM
    (LPTOKEN lptkFunc,
     LPTOKEN lptkRhtArg,
     LPTOKEN lptkAxis)

{
    static YYSTYPE YYRes;       // The result
    HGLOBAL hGlbRes;

    DBGENTER;

    // Check for axis present
    if (lptkAxis NE NULL)
    {
        ErrorMessageIndirectToken (ERRMSG_SYNTAX_ERROR APPEND_NAME,
                                   lptkFunc);
        return NULL;
    } // End IF

    // Trundle through the right arg ensuring that
    //   everything is numeric -- if not signal DOMAIN ERROR

    // Split cases based upon the right arg's token type
    switch (lptkRhtArg->tkFlags.TknType)
    {
        case TKT_VARNAMED:
            // tkData is an LPSYMENTRY
            Assert (GetPtrTypeDir (lptkRhtArg->tkData.lpVoid) EQ PTRTYPE_STCONST);

            // If it's not immediate, we must traverse the array
            if (!lptkRhtArg->tkData.lpSym->stFlags.Imm)
            {
                hGlbRes = lptkRhtArg->tkData.lpSym->stData.stGlbData;

                // stData is a valid HGLOBAL variable array
                Assert (IsGlbTypeVarDir (hGlbRes));

                // Check for all simple numeric (or coercible) leaves
                hGlbRes = PrimFnMonPlusGlb_EM (ClrPtrTypeDirGlb (hGlbRes), lptkFunc);
                if (!hGlbRes)
                    return NULL;

                // Fill in the result token
                YYRes.tkToken.tkFlags.TknType   = TKT_VARARRAY;
////////////////YYRes.tkToken.tkFlags.ImmType   = 0;
////////////////YYRes.tkToken.tkFlags.NoDisplay = 0;
////////////////YYRes.tkToken.tkFlags.Color     =
                YYRes.tkToken.tkData.tkGlbData  = MakeGlbTypeGlb (hGlbRes);
                YYRes.tkToken.tkCharIndex       = lptkFunc->tkCharIndex;

                DBGEXIT;

                return &YYRes;
            } // End IF

            // Handle the immediate case

            if (!PrimFnMonPlusCon_EM (lptkRhtArg->tkData.lpSym,
                                      lptkFunc))
                return NULL;

            // Fill in the result token
            YYRes.tkToken.tkFlags.TknType   = TKT_VARIMMED;
            YYRes.tkToken.tkFlags.ImmType   = lptkRhtArg->tkData.lpSym->stFlags.ImmType;
////////////YYRes.tkToken.tkFlags.NoDisplay = 0;
////////////YYRes.tkToken.tkFlags.Color     =
            YYRes.tkToken.tkData.tkLongest  = lptkRhtArg->tkData.lpSym->stData.stLongest;
            YYRes.tkToken.tkCharIndex       = lptkFunc->tkCharIndex;

            DBGEXIT;

            return &YYRes;

////////////break;              // Continue with common reuse code

        case TKT_VARIMMED:
            // Check for CHAR only
            if (lptkRhtArg->tkFlags.ImmType EQ IMMTYPE_CHAR)
            {
                // Mark as a DOMAIN ERROR
                ErrorMessageIndirectToken (ERRMSG_DOMAIN_ERROR APPEND_NAME,
                                           lptkFunc);
                return NULL;
            } // End IF

            // Fill in the result token
            YYRes.tkToken.tkFlags.TknType   = TKT_VARIMMED;
            YYRes.tkToken.tkFlags.ImmType   = lptkRhtArg->tkFlags.ImmType;
////////////YYRes.tkToken.tkFlags.NoDisplay = 0;
////////////YYRes.tkToken.tkFlags.Color     =
            YYRes.tkToken.tkData            = lptkRhtArg->tkData;
            YYRes.tkToken.tkCharIndex       = lptkFunc->tkCharIndex;

            DBGEXIT;

            return &YYRes;

        case TKT_VARARRAY:
            hGlbRes = lptkRhtArg->tkData.tkGlbData;

            // tkData is a valid HGLOBAL variable array
            Assert (IsGlbTypeVarDir (hGlbRes));

            // Check for all simple numeric (or coercible) leaves
            hGlbRes = PrimFnMonPlusGlb_EM (ClrPtrTypeDirGlb (hGlbRes), lptkFunc);
            if (!hGlbRes)
                return NULL;

            // Fill in the result token
            YYRes.tkToken.tkFlags.TknType   = TKT_VARARRAY;
////////////YYRes.tkToken.tkFlags.ImmType   = 0;
////////////YYRes.tkToken.tkFlags.NoDisplay = 0;
////////////YYRes.tkToken.tkFlags.Color     =
            YYRes.tkToken.tkData.tkGlbData  = MakeGlbTypeGlb (hGlbRes);
            YYRes.tkToken.tkCharIndex       = lptkFunc->tkCharIndex;

            DBGEXIT;

            return &YYRes;

        case TKT_LIST:
            ErrorMessageIndirectToken (ERRMSG_SYNTAX_ERROR APPEND_NAME,
                                       lptkFunc);
            return NULL;

        defstop
            return NULL;
    } // End SWITCH

    DbgStop ();         // We should never get here

    return NULL;
} // End PrimFnMonPlus_EM
#undef  APPEND_NAME


//***************************************************************************
//  PrimFnMonPlusCon_EM
//
//  Monadic plus on a symbol table constant
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- PrimFnMonPlusCon_EM"
#else
#define APPEND_NAME
#endif

BOOL PrimFnMonPlusCon_EM
    (LPSYMENTRY lpSym,
     LPTOKEN    lptkFunc)

{
    // stData is an immediate
    Assert (lpSym->stFlags.Imm);

    // Check for CHAR only
    if (lpSym->stFlags.ImmType EQ IMMTYPE_CHAR)
    {
        // Mark as a DOMAIN ERROR
        ErrorMessageIndirectToken (ERRMSG_DOMAIN_ERROR APPEND_NAME,
                                   lptkFunc);
        return FALSE;
    } else
        return TRUE;
} // End PrimFnMonPlusCon_EM
#undef  APPEND_NAME


//***************************************************************************
//  PrimFnMonPlusGlb_EM
//
//  Monadic plus on a global memory object
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- PrimFnMonPlusGlb_EM"
#else
#define APPEND_NAME
#endif

HGLOBAL PrimFnMonPlusGlb_EM
    (HGLOBAL hGlbRht,
     LPTOKEN lptkFunc)

{
    LPVOID   lpMem = NULL;
    HGLOBAL  hGlbSub;
    UINT     u;
    APLSTYPE cArrType;          // The array storage type (see enum ARRAY_TYPES)
    APLNELM  aplNELM;           // # elements in the array
    APLRANK  aplRank;           // The rank of the array
    BOOL     bRet = TRUE;

    DBGENTER;

    // Lock the memory to get a ptr to it
    lpMem = MyGlobalLock (hGlbRht);

#define lpHeader    ((LPVARARRAY_HEADER) lpMem)

    // Save the Type, NELM, and Rank
    cArrType = lpHeader->ArrType;
    aplNELM  = lpHeader->NELM;
    aplRank  = lpHeader->Rank;

    // If the array is empty char, change it to BOOL
    if (aplNELM EQ 0 && cArrType EQ ARRAY_CHAR)
    {
        // We no longer need this ptr
        MyGlobalUnlock (hGlbRht); lpMem = NULL;

#undef  lpHeader

        // Copy the array as we're changing it
        hGlbRht = CopyArray_EM (hGlbRht, TRUE, lptkFunc);
        if (!hGlbRht)
            return NULL;

        // Lock the memory to get a ptr to it
        lpMem = MyGlobalLock (hGlbRht);

#define lpHeader    ((LPVARARRAY_HEADER) lpMem)

        // Change the storage type to BOOL
        cArrType = lpHeader->ArrType = ARRAY_BOOL;
    } else
    {
        // We no longer need this ptr
        MyGlobalUnlock (hGlbRht); lpMem = NULL;

        // Increment the reference count as we're returning
        //   this HGLOBAL as the result
        hGlbRht = CopyArray_EM (hGlbRht, FALSE, lptkFunc);

        // Lock the memory to get a ptr to it
        lpMem = MyGlobalLock (hGlbRht);
    } // End IF/ELSE

#undef  lpHeader

    // Split cases based upon the array storage type
    switch (cArrType)
    {
        case ARRAY_BOOL:
        case ARRAY_INT:
        case ARRAY_FLOAT:
        case ARRAY_APA:
            break;

        case ARRAY_CHAR:
            ErrorMessageIndirectToken (ERRMSG_DOMAIN_ERROR APPEND_NAME,
                                       lptkFunc);
            bRet = FALSE;

            break;

        case ARRAY_HETERO:
        case ARRAY_NESTED:
            // Skip over the header and dimensions to the data
            lpMem = VarArrayBaseToData (lpMem, aplRank);

            // Traverse the array looking for DOMAIN ERRORs
            for (u = 0; bRet && u < aplNELM; u++, ((APLNESTED *) lpMem)++)
            switch (GetPtrTypeInd (lpMem))
            {
                case PTRTYPE_STCONST:
                    bRet = PrimFnMonPlusCon_EM (ClrPtrTypeIndSym (lpMem),
                                                lptkFunc);
                    break;

                case PTRTYPE_HGLOBAL:
                    Assert (cArrType EQ ARRAY_NESTED);

                    // Check for all simple numeric (or coercible) leaves
                    hGlbSub = PrimFnMonPlusGlb_EM (ClrPtrTypeIndGlb (lpMem), lptkFunc);

                    if (hGlbSub)
                    {
                        // Out with the old, ...
                        FreeResultGlobalVar (*(LPAPLNESTED) lpMem);

                        // In with the new
                        *((LPAPLNESTED) lpMem) = hGlbSub;
                    } else
                        bRet = FALSE;
                    break;

                defstop
                    break;
            } // End FOR

            break;

        case ARRAY_LIST:
            ErrorMessageIndirectToken (ERRMSG_SYNTAX_ERROR APPEND_NAME,
                                       lptkFunc);
            bRet = FALSE;

            break;

        defstop
            break;
    } // End SWITCH

    if (lpMem)
    {
        // We no longer need this ptr
        MyGlobalUnlock (hGlbRht); lpMem = NULL;
    } // End IF

    if (bRet)
    {
        DBGEXIT;

        return hGlbRht;
    } // End IF

    // Decrement the reference count, possibly freeing it
    FreeResultGlobalVar (hGlbRht); hGlbRht = NULL;

    DBGEXIT;

    return NULL;
} // End PrimFnMonPlusGlb_EM
#undef  APPEND_NAME


//***************************************************************************
//  PrimFnDydPlus_EM
//
//  Primitive function for dydadic plus (addition)
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- PrimFnDydPlus_EM"
#else
#define APPEND_NAME
#endif

LPYYSTYPE PrimFnDydPlus_EM
    (LPTOKEN lptkLftArg,
     LPTOKEN lptkFunc,
     LPTOKEN lptkRhtArg,
     LPTOKEN lptkAxis)

{
    static YYSTYPE YYRes;   // The result
    APLRANK  aplRankLft,
             aplRankRht,
             aplRankRes;
    APLNELM  aplNELMAxis,
             aplNELMLft,
             aplNELMRht,
             aplNELMRes;
    HGLOBAL  hGlbAxis,
             hGlbRes = NULL,
             hGlbRht = NULL,
             hGlbLft = NULL;
    APLSTYPE cArrTypeLft,
             cArrTypeRht,
             cArrTypeRes;
    LPAPLINT lpMemAxisHead = NULL,
             lpMemAxisTail;
    LPVOID   lpMemLft = NULL,
             lpMemRht = NULL,
             lpMemRes = NULL;
    APLINT   aplInteger;
    BOOL     bRet = TRUE;
    BOOL   (*PrimFn) (LPYYSTYPE,
                      LPTOKEN,
                      LPTOKEN,
                      LPTOKEN,
                      HGLOBAL,
                      HGLOBAL,
                      HGLOBAL *,
                      LPVOID *,
                      LPVOID *,
                      LPVOID *,
                      LPAPLINT,
                      LPAPLINT,
                      APLRANK,
                      APLRANK,
                      APLRANK,
                      APLSTYPE,
                      APLSTYPE,
                      APLSTYPE,
                      APLNELM,
                      APLNELM,
                      APLNELM,
                      APLNELM);

    DBGENTER;

    // Get the attributes (Type, NELM, and Rank)
    //   of the left & right args
    AttrsOfToken (lptkLftArg, &cArrTypeLft, &aplNELMLft, &aplRankLft);
    AttrsOfToken (lptkRhtArg, &cArrTypeRht, &aplNELMRht, &aplRankRht);

    // The rank of the result is the larger of the two args
    aplRankRes = max (aplRankLft, aplRankRht);

    // Check for axis present
    if (lptkAxis NE NULL)
    {
        // Check the axis values, fill in # elements in axis
        if (!CheckAxis_EM (lptkAxis,        // The axis token
                           aplRankRes,      // All values less than this
                           FALSE,           // TRUE if scalar or one-element vector only
                           TRUE,            // TRUE if want sorted axes
                           NULL,            // Return last axis value
                           &aplNELMAxis,    // Return # elements in axis vector
                           &hGlbAxis))      // Return HGLOBAL with APLINT axis values
            return NULL;

        // Lock the memory to get a ptr to it
        lpMemAxisHead = MyGlobalLock (hGlbAxis);

        // Get pointer to the axis tail (where the [X] values are)
        lpMemAxisTail = &lpMemAxisHead[aplRankRes - aplNELMAxis];
    } else
        // No axis is the same as all axes
        aplNELMAxis = aplRankRes;

    // In case the left arg is an empty char,
    //   change its type to BOOL
    if (aplNELMLft EQ 0 && cArrTypeLft EQ ARRAY_CHAR)
        cArrTypeLft = ARRAY_BOOL;

    // In case the right arg is an empty char,
    //   change its type to BOOL
    if (aplNELMRht EQ 0 && cArrTypeRht EQ ARRAY_CHAR)
        cArrTypeRht = ARRAY_BOOL;

    // Calculate the storage type of the result
    cArrTypeRes = StorageType (cArrTypeLft, lptkFunc, cArrTypeRht);
    if (cArrTypeRes EQ ARRAY_ERROR)
    {
        ErrorMessageIndirectToken (ERRMSG_DOMAIN_ERROR APPEND_NAME,
                                   lptkFunc);
        goto ERROR_EXIT;
    } // End IF

    // No Boolean results for addition
    if (cArrTypeRes EQ ARRAY_BOOL)
        cArrTypeRes = ARRAY_INT;

    // Special case addition with APA
    if (cArrTypeRes EQ ARRAY_INT                        // Res = INT
     && (aplNELMLft NE 1 || aplNELMRht NE 1)            // Not both singletons
     && ((aplNELMLft EQ 1 && cArrTypeRht EQ ARRAY_APA)  // Non-singleton is APA
      || (aplNELMRht EQ 1 && cArrTypeLft EQ ARRAY_APA)))// ...
        cArrTypeRes = ARRAY_APA;

    Assert (IsSimpleNum (cArrTypeRes)
         || cArrTypeRes EQ ARRAY_NESTED);

    // Get global ptrs
    GetGlbPtrs (lptkLftArg, &hGlbLft, &lpMemLft);
    GetGlbPtrs (lptkRhtArg, &hGlbRht, &lpMemRht);

    // Check for RANK and LENGTH ERRORs
    if (!CheckRankLengthError_EM (aplRankRes,
                                  aplRankLft,
                                  aplNELMLft,
                                  lpMemLft,
                                  aplRankRht,
                                  aplNELMRht,
                                  lpMemRht,
                                  aplNELMAxis,
                                  lpMemAxisTail,
                                  lptkFunc))
        goto ERROR_EXIT;

    // The NELM of the result is the larger of the two args
    //   unless one is empty
    if (aplNELMLft EQ 0 || aplNELMRht EQ 0)
        aplNELMRes = 0;
    else
        aplNELMRes = max (aplNELMLft, aplNELMRht);

    // Five cases:
    //   Result     Left       Right
    //   ----------------------------
    //   APA        ...        ...
    //   Simple     Simple     Simple
    //   Nested     Simple     Nested
    //   Nested     Nested     Simple
    //   Nested     Nested     Nested

    if (cArrTypeRes EQ ARRAY_APA)
    {
        if (cArrTypeLft EQ ARRAY_APA)
            FirstValue (lptkRhtArg, &aplInteger, NULL, NULL, NULL, NULL);
        else
            FirstValue (lptkLftArg, &aplInteger, NULL, NULL, NULL, NULL);

        if (!PrimFnDydPlusAPA_EM (&YYRes,
                                   lptkFunc,
                                   hGlbLft,
                                   hGlbRht,
                                  &hGlbRes,
                                  &lpMemRes,
                                   aplRankLft,
                                   aplRankRht,
                                   aplNELMLft,
                                   aplInteger))
            goto ERROR_EXIT;
        else
            goto NORMAL_EXIT;
    } // End IF

    // Allocate space for result
    if (!PrimScalarFnDydAllocate_EM (lptkFunc,
                                    &hGlbRes,
                                     lpMemLft,
                                     lpMemRht,
                                    &lpMemRes,
                                     aplRankLft,
                                     aplRankRht,
                                    &aplRankRes,
                                     cArrTypeRes,
                                     aplNELMLft,
                                     aplNELMRht,
                                     aplNELMRes))
        goto ERROR_EXIT;

    // Split cases based upon the combined left vs. right types
    if (cArrTypeLft EQ ARRAY_NESTED
     && cArrTypeRht EQ ARRAY_NESTED)
        // Left arg is NESTED, right arg is NESTED
        PrimFn = PrimFnDydPlusNestNest_EM;
    else
    if (cArrTypeLft NE ARRAY_NESTED
     && cArrTypeRht EQ ARRAY_NESTED)
        // Left arg is SIMPLE, right arg is NESTED
        PrimFn = PrimFnDydPlusSimpNest_EM;
    else
    if (cArrTypeLft EQ ARRAY_NESTED
     && cArrTypeRht NE ARRAY_NESTED)
        // Left arg is NESTED, right arg is SIMPLE
        PrimFn = PrimFnDydPlusNestSimp_EM;
    else
    if (cArrTypeLft NE ARRAY_NESTED
     && cArrTypeRht NE ARRAY_NESTED)
        // Left arg is SIMPLE, right arg is SIMPLE
        PrimFn = PrimFnDydPlusSimpSimp_EM;
    else
        DbgStop ();     // We should never get here

    // Call the appropriate function
    if (!(*PrimFn) (&YYRes,
                     lptkLftArg,
                     lptkFunc,
                     lptkRhtArg,
                     hGlbLft,
                     hGlbRht,
                    &hGlbRes,
                     lpMemLft,          // Points to sign.ature
                     lpMemRht,          // ...
                     lpMemRes,          // ...
                     lpMemAxisHead,
                     lpMemAxisTail,
                     aplRankLft,
                     aplRankRht,
                     aplRankRes,
                     cArrTypeLft,
                     cArrTypeRht,
                     cArrTypeRes,
                     aplNELMLft,
                     aplNELMRht,
                     aplNELMRes,
                     aplNELMAxis))
        goto ERROR_EXIT;
    else
        goto NORMAL_EXIT;

ERROR_EXIT:
    bRet = FALSE;

    if (hGlbRes)
    {
        if (lpMemRes)
        {
            // We no longer need this ptr
            MyGlobalUnlock (hGlbRes); lpMemRes = NULL;
        } // End IF

        // We no longer need this storage
        FreeResultGlobalVar (hGlbRes); hGlbRes = NULL;
    } // End IF
NORMAL_EXIT:
    if (hGlbRes && lpMemRes)
    {
        // We no longer need this ptr
        MyGlobalUnlock (hGlbRes); lpMemRes = NULL;
    } // End IF

    if (hGlbLft && lpMemLft)
    {
        // We no longer need this ptr
        MyGlobalUnlock (hGlbLft); lpMemLft = NULL;
    } // End IF

    if (hGlbRht && lpMemRht)
    {
        // We no longer need this ptr
        MyGlobalUnlock (hGlbRht); lpMemRht = NULL;
    } // End IF

    if (hGlbAxis && lpMemAxisHead)
    {
        // We no longer need this ptr
        MyGlobalUnlock (hGlbAxis); lpMemAxisHead = lpMemAxisTail = NULL;
    } // End IF

    DBGEXIT;

    if (bRet)
        return &YYRes;
    else
        return NULL;
} // End PrimFnDydPlus_EM
#undef  APPEND_NAME


//***************************************************************************
//  PrimFnDydPlusNestNest_EM
//
//  Dyadic plus, left nested, right nested
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- PrimFnDydPlusNestNest_EM"
#else
#define APPEND_NAME
#endif

BOOL PrimFnDydPlusNestNest_EM
    (LPYYSTYPE lpYYRes,

     LPTOKEN   lptkLftArg,
     LPTOKEN   lptkFunc,
     LPTOKEN   lptkRhtArg,

     HGLOBAL   hGlbLft,
     HGLOBAL   hGlbRht,
     HGLOBAL  *lphGlbRes,

     LPVOID    lpMemLft,            // Points to sign.ature
     LPVOID    lpMemRht,            // ...
     LPVOID    lpMemRes,            // ...

     LPAPLINT  lpMemAxisHead,
     LPAPLINT  lpMemAxisTail,

     APLRANK   aplRankLft,
     APLRANK   aplRankRht,
     APLRANK   aplRankRes,

     APLSTYPE  cArrTypeLft,
     APLSTYPE  cArrTypeRht,
     APLSTYPE  cArrTypeRes,

     APLNELM   aplNELMLft,
     APLNELM   aplNELMRht,
     APLNELM   aplNELMRes,
     APLNELM   aplNELMAxis)

{
    BOOL   bRet = TRUE;
    APLINT uRes;

    DBGENTER;

    // Check for INNER RANK and LENGTH ERRORs
    if (!CheckRankLengthError_EM (aplRankRes,
                                  aplRankLft,
                                  aplNELMLft,
                                  lpMemLft,
                                  aplRankRht,
                                  aplNELMRht,
                                  lpMemRht,
                                  aplNELMAxis,
                                  lpMemAxisTail,
                                  lptkFunc))
        goto ERROR_EXIT;

    // Skip over the headers and dimensions to the data
    lpMemLft = VarArrayBaseToData (lpMemLft, aplRankLft);
    lpMemRht = VarArrayBaseToData (lpMemRht, aplRankRht);
    lpMemRes = VarArrayBaseToData (lpMemRes, aplRankRes);

    // Loop through the left and right args
    for (uRes = 0; bRet && uRes < aplNELMRes; uRes++)
    {
        TOKEN     tkLft = {0},
                  tkRht = {0};
        LPYYSTYPE lpYYRes;

        tkLft.tkFlags.TknType   = TKT_VARARRAY;
////////tkLft.TknType.ImmType   = 0;
////////tkLft.TknType.NoDisplay = 0;
////////tkLft.TknType.Color     = ??
        tkLft.tkData.tkGlbData  = ((LPAPLNESTED) lpMemLft)[uRes % aplNELMLft];
        tkLft.tkCharIndex       = lptkLftArg->tkCharIndex;

        tkRht.tkFlags.TknType   = TKT_VARARRAY;
////////tkRht.TknType.ImmType   = 0;
////////tkRht.TknType.NoDisplay = 0;
////////tkRht.TknType.Color     = ??
        tkRht.tkData.tkGlbData  = ((LPAPLNESTED) lpMemRht)[uRes % aplNELMRht];
        tkRht.tkCharIndex       = lptkRhtArg->tkCharIndex;

        lpYYRes = PrimFnDydPlus_EM (&tkLft, lptkFunc, &tkRht, NULL);
        if (lpYYRes)
            ((LPAPLNESTED) lpMemRes)[uRes] = lpYYRes->tkToken.tkData.tkGlbData;
        else
            bRet = FALSE;
    } // End FOR

    if (bRet)
    {
        // Fill in the result token
        lpYYRes->tkToken.tkFlags.TknType   = TKT_VARARRAY;
////////lpYYRes->tkToken.tkFlags.ImmType   = 0;
////////lpYYRes->tkToken.tkFlags.NoDisplay = 0;
////////lpYYRes->tkToken.tkFlags.Color     =
        lpYYRes->tkToken.tkData.tkGlbData  = MakeGlbTypeGlb (*lphGlbRes);
    } // End IF

ERROR_EXIT:
    DBGEXIT;

    return bRet;
} // End PrimFnDydPlusNestNest_EM
#undef  APPEND_NAME


//***************************************************************************
//  PrimFnDydPlusNestSimp_EM
//
//  Dyadic plus, left nested, right simple
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- PrimFnDydPlusNestSimp_EM"
#else
#define APPEND_NAME
#endif

BOOL PrimFnDydPlusNestSimp_EM
    (LPYYSTYPE lpYYRes,

     LPTOKEN   lptkLftArg,
     LPTOKEN   lptkFunc,
     LPTOKEN   lptkRhtArg,

     HGLOBAL   hGlbLft,
     HGLOBAL   hGlbRht,
     HGLOBAL  *lphGlbRes,

     LPVOID    lpMemLft,
     LPVOID    lpMemRht,
     LPVOID    lpMemRes,

     LPAPLINT  lpMemAxisHead,
     LPAPLINT  lpMemAxisTail,

     APLRANK   aplRankLft,
     APLRANK   aplRankRht,
     APLRANK   aplRankRes,

     APLSTYPE  cArrTypeLft,
     APLSTYPE  cArrTypeRht,
     APLSTYPE  cArrTypeRes,

     APLNELM   aplNELMLft,
     APLNELM   aplNELMRht,
     APLNELM   aplNELMRes,
     APLNELM   aplNELMAxis)

{
    // Because addition is commutative, we call the
    //   Left Simp, Right Nested function with the
    //   relevant left and right arguments switched.
    return PrimFnDydPlusSimpNest_EM
           (lpYYRes,
            lptkRhtArg,
            lptkFunc,
            lptkLftArg,
            hGlbRht,
            hGlbLft,
            lphGlbRes,
            lpMemRht,
            lpMemLft,
            lpMemRes,
            lpMemAxisHead,
            lpMemAxisTail,
            aplRankRht,
            aplRankLft,
            aplRankRes,
            cArrTypeRht,
            cArrTypeLft,
            cArrTypeRes,
            aplNELMRht,
            aplNELMLft,
            aplNELMRes,
            aplNELMAxis);
} // End PrimFnDydPlusNestSimp_EM
#undef  APPEND_NAME


//***************************************************************************
//  PrimFnDydPlusSimpNest_EM
//
//  Dyadic plus, left simple, right nested
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- PrimFnDydPlusSimpNest_EM"
#else
#define APPEND_NAME
#endif

BOOL PrimFnDydPlusSimpNest_EM
    (LPYYSTYPE lpYYRes,

     LPTOKEN   lptkLftArg,
     LPTOKEN   lptkFunc,
     LPTOKEN   lptkRhtArg,

     HGLOBAL   hGlbLft,
     HGLOBAL   hGlbRht,
     HGLOBAL  *lphGlbRes,

     LPVOID    lpMemLft,
     LPVOID    lpMemRht,
     LPVOID    lpMemRes,

     LPAPLINT  lpMemAxisHead,
     LPAPLINT  lpMemAxisTail,

     APLRANK   aplRankLft,
     APLRANK   aplRankRht,
     APLRANK   aplRankRes,

     APLSTYPE  cArrTypeLft,
     APLSTYPE  cArrTypeRht,
     APLSTYPE  cArrTypeRes,

     APLNELM   aplNELMLft,
     APLNELM   aplNELMRht,
     APLNELM   aplNELMRes,
     APLNELM   aplNELMAxis)

{
    BOOL       bRet = TRUE;
    APLINT     uRes;
    APLINT     aplIntegerLft,
               apaOffLft,
               apaMulLft,
               ByteAlloc;
    APLINTSIGN iDim;
    APLFLOAT   aplFloatLft;
    HGLOBAL    hGlbWVec = NULL,
               hGlbOdo = NULL,
               hGlbProto,
               hGlbSub;
    LPAPLINT   lpMemWVec = NULL,
               lpMemLftDim,
               lpMemRhtDim,
               lpMemResDim,
               lpMemOdo = NULL;

    DBGENTER;

    // If the left arg is immediate, get the one and only value
    if (!lpMemLft)
        FirstValue (lptkLftArg, &aplIntegerLft, &aplFloatLft, NULL, NULL, NULL);
    else
    {
        // Skip over the header to the dimensions
        lpMemLftDim = VarArrayBaseToDim (lpMemLft);

        // Skip over the header and dimensions to the data
        lpMemLft = VarArrayBaseToData (lpMemLft, aplRankLft);
    } // End IF/ELSE

    // If the left arg is APA, get its parameters
    if (cArrTypeLft EQ ARRAY_APA)
    {

#define lpAPA   ((LPAPLAPA) lpMemLft)

        apaOffLft = lpAPA->Off;
        apaMulLft = lpAPA->Mul;

#undef  lpAPA
    } // End IF

    // Skip over the header to the dimensions
    lpMemRhtDim = VarArrayBaseToDim (lpMemRht);
    lpMemResDim = VarArrayBaseToDim (lpMemRes);

    // Skip over the header and dimensions to the data
    lpMemRht = VarArrayBaseToData (lpMemRht, aplRankRht);
    lpMemRes = VarArrayBaseToData (lpMemRes, aplRankRes);

    // Handle prototype case
    if (aplNELMRes EQ 0)
    {
        hGlbProto = MakeGlbTypeGlb (hGlbRht);

        // Check to see if the first element is simple.
        // If so, fill in cArrTypeRes; if not, fill in hGlbProto
        //   with the HGLOBAL of the first element.
        IsFirstSimpleGlb (&hGlbProto, &cArrTypeRes);

        // Check for all simple numeric (or coercible) leaves
        hGlbProto = PrimFnMonPlusGlb_EM (ClrPtrTypeDirGlb (hGlbProto), lptkFunc);
        if (hGlbProto)
        {
            // Make the prototype
            hGlbSub = MakePrototype_EM (hGlbProto,
                                        lptkFunc);
            if (hGlbSub)
                // Save the handle
                *((LPAPLNESTED) lpMemRes) = MakeGlbTypeGlb (hGlbSub);
            else
            {
                // We no longer need this storage
                FreeResultGlobalVar (hGlbProto); hGlbProto = NULL;

                goto ERROR_EXIT;
            } // End IF/ELSE
        } else
            goto ERROR_EXIT;
    } else
    {
        // Handle axis if present
        if (aplNELMAxis NE aplRankRes)
        {
            //***************************************************************
            // Allocate space for the weighting vector which is
            //   {times}{backscan}1{drop}({rho}Z),1
            // N.B.  Conversion from APLINT to UINT.
            //***************************************************************
            ByteAlloc = aplRankRes * sizeof (APLINT);
            Assert (ByteAlloc EQ (UINT) ByteAlloc);
            hGlbWVec = DbgGlobalAlloc (GHND, (UINT) ByteAlloc);
            if (!hGlbWVec)
            {
                ErrorMessageIndirectToken (ERRMSG_WS_FULL APPEND_NAME,
                                           lptkFunc);
                goto ERROR_EXIT;
            } // End IF

            // Lock the memory to get a ptr to it
            lpMemWVec = MyGlobalLock (hGlbWVec);

            // Loop through the dimensions of the result in reverse
            //   order {backscan} and compute the cumulative product
            //   (weighting vector).
            // Note we use a signed index variable because we're
            //   walking backwards and the test against zero must be
            //   made as a signed variable.
            for (uRes = 1, iDim = aplRankRes - 1; iDim >= 0; iDim--)
            {
                lpMemWVec[iDim] = uRes;
                uRes *= lpMemResDim[iDim];
            } // End FOR

            //***************************************************************
            // Allocate space for the odometer array, one value per dimension
            //   in the right arg, with values initially all zero (thanks to GHND).
            // N.B.  Conversion from APLINT to UINT.
            //***************************************************************
            ByteAlloc = aplRankRes * sizeof (APLINT);
            Assert (ByteAlloc EQ (UINT) ByteAlloc);
            hGlbOdo = DbgGlobalAlloc (GHND, (UINT) ByteAlloc);
            if (!hGlbOdo)
            {
                ErrorMessageIndirectToken (ERRMSG_WS_FULL APPEND_NAME,
                                           lptkFunc);
                goto ERROR_EXIT;
            } // End IF

            // Lock the global memory to get a ptr to it
            lpMemOdo = MyGlobalLock (hGlbOdo);
        } // End IF

        // Loop through the # elements in the result
        for (uRes = 0; bRet && uRes < aplNELMRes; uRes++)
        {
            APLINT uLft, uRht, uArg;

            // If the left arg is not immediate, get the next value
            if (lpMemLft)
            {
                if (aplNELMAxis NE aplRankRes)
                {
                    // Loop through the odometer values accumulating
                    //   the weighted sum
                    for (uArg = 0, uRht = aplRankRes - aplNELMAxis; uRht < aplRankRes; uRht++)
                        uArg += lpMemOdo[lpMemAxisHead[uRht]] * lpMemWVec[uRht];

                    // Increment the odometer in lpMemOdo subject to
                    //   the values in lpMemDimRes
                    IncrOdometer (lpMemOdo, lpMemResDim, NULL, aplRankRes);

                    // Use the just computed index for the argument
                    //   with the smaller rank
                    if (aplRankLft < aplRankRht)
                    {
                        uLft = uArg;
                        uRht = uRes;
                    } else
                    {
                        uRht = uArg;
                        uLft = uRes;
                    } // End IF/ELSE
                } else
                {
                    uLft = uRes % aplNELMLft;
                    uRht = uRes % aplNELMRht;
                } // End IF/ELSE

                if (cArrTypeLft EQ ARRAY_FLOAT)
                    aplFloatLft   = GetNextFloat   (lpMemLft, cArrTypeLft, uLft, apaOffLft, apaMulLft);
                else
                    aplIntegerLft = GetNextInteger (lpMemLft, cArrTypeLft, uLft, apaOffLft, apaMulLft);
            } else
                uRht = uRes;

            hGlbSub = PrimFnDydPlusSimpNestSub_EM (lptkFunc,
                                                   cArrTypeLft,
                                                   aplIntegerLft,
                                                   aplFloatLft,
                                                   ((LPAPLNESTED) lpMemRht)[uRht]);
            if (!hGlbSub)
                goto ERROR_EXIT;
            else
                *((LPAPLNESTED) lpMemRes)++ = MakeGlbTypeGlb (hGlbSub);
        } // End FOR
    } // End IF/ELSE/...

    // Fill in the result token
    lpYYRes->tkToken.tkFlags.TknType   = TKT_VARARRAY;
////lpYYRes->tkToken.tkFlags.ImmType   = 0;
////lpYYRes->tkToken.tkFlags.NoDisplay = 0;
////lpYYRes->tkToken.tkFlags.Color     =
    lpYYRes->tkToken.tkData.tkGlbData  = MakeGlbTypeGlb (*lphGlbRes);

    goto NORMAL_EXIT;

ERROR_EXIT:
    bRet = FALSE;
NORMAL_EXIT:
    if (lpMemWVec)
    {
        // We no longer need this ptr
        MyGlobalUnlock (hGlbWVec); lpMemWVec = NULL;
    } // End IF

    if (lpMemOdo)
    {
        // We no longer need this ptr
        MyGlobalUnlock (hGlbOdo); lpMemOdo = NULL;
    } // End IF

    if (hGlbWVec)
    {
        // We no longer need this storage
        DbgGlobalFree (hGlbWVec); hGlbWVec = NULL;
    } // End IF

    if (hGlbOdo)
    {
        // We no longer need this storage
        DbgGlobalFree (hGlbOdo); hGlbOdo = NULL;
    } // End IF

    DBGEXIT;

    return bRet;
} // End PrimFnDydPlusSimpNest_EM
#undef  APPEND_NAME


//***************************************************************************
//  PrimFnDydPlusSimpNestSub_EM
//
//  Subroutine to PrimFnDydPlusSimpNest_EM
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- PrimFnDydPlusSimpNestSub_EM"
#else
#define APPEND_NAME
#endif

HGLOBAL PrimFnDydPlusSimpNestSub_EM
    (LPTOKEN   lptkFunc,
     APLSTYPE  cArrTypeLft,
     APLINT    aplIntegerLft,
     APLFLOAT  aplFloatLft,
     APLNESTED aplNestedRht)

{
    BOOL     bRet = TRUE;
    HGLOBAL  hGlbRht = NULL,
             hGlbRes = NULL,
             hGlbSub;
    LPVOID   lpMemRht,
             lpMemRes = NULL;
    APLSTYPE cArrTypeRht,
             cArrTypeRes;
    APLNELM  aplNELMLft = 1,
             aplNELMRht,
             aplNELMRes;
    APLRANK  aplRankLft = 0,
             aplRankRht,
             aplRankRes;
    APLINT   uRht,
             apaOff,
             apaMul;
    UINT     uBitIndex;

    DBGENTER;

    // The right arg data is a valid HGLOBAL array
    Assert (IsGlbTypeVarDir (aplNestedRht));

    // Clear the identifying bits
    hGlbRht = ClrPtrTypeDirGlb (aplNestedRht);

    // Lock the memory to get a ptr to it
    lpMemRht = MyGlobalLock (hGlbRht);

#define lpHeader    ((LPVARARRAY_HEADER) lpMemRht)

    cArrTypeRht = lpHeader->ArrType;
    aplNELMRht  = lpHeader->NELM;
    aplRankRht  = lpHeader->Rank;

#undef  lpHeader

    // The NELM of the result is the larger of the two arg's NELMs
    aplNELMRes = max (aplNELMLft, aplNELMRht);

    // In case the right arg is an empty char,
    //   change its type to BOOL
    if (aplNELMRht EQ 0 && cArrTypeRht EQ ARRAY_CHAR)
        cArrTypeRht = ARRAY_BOOL;

    // Calculate the storage type of the result
    cArrTypeRes = StorageType (cArrTypeLft, lptkFunc, cArrTypeRht);
    if (cArrTypeRes EQ ARRAY_ERROR)
    {
        ErrorMessageIndirectToken (ERRMSG_DOMAIN_ERROR APPEND_NAME,
                                   lptkFunc);
        goto ERROR_EXIT;
    } // End IF

    // No Boolean results for addition
    if (cArrTypeRes EQ ARRAY_BOOL)
        cArrTypeRes = ARRAY_INT;

    // Special case addition with APA
    if (cArrTypeRes EQ ARRAY_INT                        // Res = INT
     && (aplNELMLft NE 1 || aplNELMRht NE 1)            // Not both singletons
     && ((aplNELMLft EQ 1 && cArrTypeRht EQ ARRAY_APA)  // Non-singleton is APA
      || (aplNELMRht EQ 1 && cArrTypeLft EQ ARRAY_APA)))// ...
    {
        if (!PrimFnDydPlusAPA_EM (NULL,
                                  lptkFunc,
                                  NULL,
                                  hGlbRht,
                                 &hGlbRes,
                                 &lpMemRes,
                                  aplRankLft,
                                  aplRankRht,
                                  aplNELMLft,
                                  aplIntegerLft))
            goto ERROR_EXIT;
        else
            goto NORMAL_EXIT;
    } // End IF

    Assert (IsSimpleNum (cArrTypeRes)
         || cArrTypeRes EQ ARRAY_NESTED);

    // Allocate space for result
    if (!PrimScalarFnDydAllocate_EM (lptkFunc,
                                    &hGlbRes,
                                     NULL,
                                     lpMemRht,
                                    &lpMemRes,
                                     aplRankLft,
                                     aplRankRht,
                                    &aplRankRes,
                                     cArrTypeRes,
                                     aplNELMLft,
                                     aplNELMRht,
                                     aplNELMRes))
        goto ERROR_EXIT;

    // Skip over the header and dimensions to the data
    lpMemRht = VarArrayBaseToData (lpMemRht, aplRankRht);
    lpMemRes = VarArrayBaseToData (lpMemRes, aplRankRes);

    // In case the non-singleton argument is Boolean
    uBitIndex = 0;

    // Split cases based upon the storage type of the right arg
    switch (cArrTypeRht)
    {
        case ARRAY_BOOL:                // Rht = BOOL
            // Split cases based upon the storage type of the left arg
            switch (cArrTypeLft)
            {
                case ARRAY_BOOL:        // Res = INT, Lft = BOOL, Rht = BOOL
                case ARRAY_INT:         // Res = INT, Lft = INT,  Rht = BOOL
                case ARRAY_APA:         // Res = INT, Lft = APA,  Rht = BOOL
                    Assert (cArrTypeRes EQ ARRAY_INT);

                    for (uRht = 0; uRht < aplNELMRht; uRht++)
                    {
                        *((LPAPLINT)   lpMemRes)++ = aplIntegerLft
                                                   + (BIT0 & ((*(LPAPLBOOL) lpMemRht) >> uBitIndex++));
                        // Check for end-of-byte
                        if (uBitIndex EQ NBIB)
                        {
                            uBitIndex = 0;              // Start over
                            ((LPAPLBOOL) lpMemRht)++;   // Skip to next byte
                        } // End IF
                    } // End FOR

                    break;

                case ARRAY_FLOAT:       // Res = FLOAT, Lft = FLOAT, Rht = Bool
                    Assert (cArrTypeRes EQ ARRAY_FLOAT);

                    for (uRht = 0; uRht < aplNELMRht; uRht++)
                    {
                        *((LPAPLFLOAT) lpMemRes)++ = aplFloatLft
                                                   + (BIT0 & ((*(LPAPLBOOL) lpMemRht) >> uBitIndex++));
                        // Check for end-of-byte
                        if (uBitIndex EQ NBIB)
                        {
                            uBitIndex = 0;              // Start over
                            ((LPAPLBOOL) lpMemRht)++;   // Skip to next byte
                        } // End IF
                    } // End FOR

                    break;

                defstop
                    break;
            } // End SWITCH

            break;

        case ARRAY_INT:                 // Rht = INT
            // Split cases based upon the storage type of the left arg
            switch (cArrTypeLft)
            {
                case ARRAY_BOOL:        // Res = INT, Lft = BOOL, Rht = INT
                case ARRAY_INT:         // Res = INT, Lft = INT,  Rht = INT
                case ARRAY_APA:         // Res = INT, Lft = APA,  Rht = INT
                    Assert (cArrTypeRes EQ ARRAY_INT);

                    for (uRht = 0; uRht < aplNELMRht; uRht++)
                        *((LPAPLINT)   lpMemRes)++ = aplIntegerLft
                                                   + *((LPAPLINT) lpMemRht)++;
                    break;

                case ARRAY_FLOAT:       // Res = FLOAT, Lft = FLOAT, Rht = INT
                    Assert (cArrTypeRes EQ ARRAY_FLOAT);

                    for (uRht = 0; uRht < aplNELMRht; uRht++)
                        *((LPAPLFLOAT) lpMemRes)++ = aplFloatLft
                                                   + (APLFLOAT) *((LPAPLINTSIGN) lpMemRht)++;
                    break;

                defstop
                    break;
            } // End SWITCH

            break;

        case ARRAY_FLOAT:               // Rht = FLOAT
            Assert (cArrTypeRes EQ ARRAY_FLOAT);

            // Split cases based upon the storage type of the left arg
            switch (cArrTypeLft)
            {
                case ARRAY_BOOL:        // Res = FLOAT, Lft = BOOL, Rht = FLOAT
                case ARRAY_INT:         // Res = FLOAT, Lft = INT,  Rht = FLOAT
                case ARRAY_APA:         // Res = FLOAT, Lft = APA,  Rht = FLOAT
                    for (uRht = 0; uRht < aplNELMRht; uRht++)
                        *((LPAPLFLOAT) lpMemRes)++ = ((APLINTSIGN) aplIntegerLft)
                                                   + *((LPAPLFLOAT) lpMemRht)++;
                    break;

                case ARRAY_FLOAT:       // Res = FLOAT, Lft = FLOAT, Rht = FLOAT
                    for (uRht = 0; uRht < aplNELMRht; uRht++)
                        *((LPAPLFLOAT) lpMemRes)++ = aplFloatLft
                                                   + *((LPAPLFLOAT) lpMemRht)++;
                    break;

                defstop
                    break;
            } // End SWITCH

            break;

        case ARRAY_APA:                 // Rht = APA
#define lpAPA       ((LPAPLAPA) lpMemRht)

            apaOff = lpAPA->Off;
            apaMul = lpAPA->Mul;

#undef  lpAPA

            // Split cases based upon the storage type of the left arg
            switch (cArrTypeLft)
            {
                case ARRAY_BOOL:        // Res = INT, Lft = BOOL, Rht = APA
                case ARRAY_INT:         // Res = INT, Lft = INT,  Rht = APA
                case ARRAY_APA:         // Res = INT, Lft = APA,  Rht = APA
                    Assert (cArrTypeRes EQ ARRAY_INT);

                    for (uRht = 0; uRht < aplNELMRht; uRht++)
                        *((LPAPLINT)   lpMemRes)++ = aplIntegerLft
                                                   + apaOff + apaMul * uRht;
                    break;

                case ARRAY_FLOAT:       // Res = FLOAT, Lft = FLOAT, Rht = INT
                    Assert (cArrTypeRes EQ ARRAY_FLOAT);

                    for (uRht = 0; uRht < aplNELMRht; uRht++)
                        *((LPAPLFLOAT) lpMemRes)++ = aplFloatLft
                                                   + (APLINTSIGN) (apaOff + apaMul * uRht);
                    break;

                defstop
                    break;
            } // End SWITCH

            break;

        case ARRAY_NESTED:              // Rht = NESTED
            Assert (cArrTypeRes EQ ARRAY_NESTED);

            for (uRht = 0; uRht < aplNELMRht; uRht++)
            {
                hGlbSub = PrimFnDydPlusSimpNestSub_EM (lptkFunc,
                                                       cArrTypeLft,
                                                       aplIntegerLft,
                                                       aplFloatLft,
                                                       ((LPAPLNESTED) lpMemRht)[uRht % aplNELMRht]);
                if (!hGlbSub)
                    bRet = FALSE;
                else
                    *((LPAPLNESTED) lpMemRes)++ = MakeGlbTypeGlb (hGlbSub);
            } // End FOR

            break;

        case ARRAY_HETERO:              // Rht = HETERO
        case ARRAY_CHAR:                // Rht = CHAR
            goto ERROR_EXIT;

        defstop
            break;
    } // End SWITCH

    goto NORMAL_EXIT;

ERROR_EXIT:
    bRet = FALSE;

    if (hGlbRes)
    {
        if (lpMemRes)
        {
            // We no longer need this ptr
            MyGlobalUnlock (hGlbRes); lpMemRes = NULL;
        } // End IF

        // We no longer need this storage
        FreeResultGlobalVar (hGlbRes); hGlbRes = NULL;
    } // End IF
NORMAL_EXIT:
    if (lpMemRes)
    {
        // We no longer need this ptr
        MyGlobalUnlock (hGlbRes); lpMemRes = NULL;
    } // End IF

    // We no longer need this ptr
    MyGlobalUnlock (hGlbRht); lpMemRht = NULL;

    DBGEXIT;

    if (bRet)
        return hGlbRes;
    else
        return NULL;
} // End PrimFnDydPlusSimpNestSub_EM
#undef  APPEND_NAME


//***************************************************************************
//  PrimFnDydPlusAPA_EM
//
//  Dyadic plus, result is APA
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- PrimFnDydPlusAPA_EM"
#else
#define APPEND_NAME
#endif

BOOL PrimFnDydPlusAPA_EM
    (LPYYSTYPE lpYYRes,     // The result token (may be NULL)

     LPTOKEN   lptkFunc,

     HGLOBAL   hGlbLft,     // HGLOBAL of left arg (may be NULL)
     HGLOBAL   hGlbRht,
     HGLOBAL  *lphGlbRes,

     LPVOID   *lplpMemRes,

     APLRANK   aplRankLft,
     APLRANK   aplRankRht,

     APLNELM   aplNELMLft,

     APLINT    aplInteger)

{
    APLRANK aplRankRes;

    DBGENTER;

    //***************************************************************
    // The result is an APA, one of the args is a simple singleton,
    //   the other an APA
    //***************************************************************

    // Axis may be anything

    // Get a ptr to each arg's header
    //   and the value of the singleton
    // Also, in case we're doing (1 1 1{rho}1)+{iota}4
    //   set the rank of the result to the rank of
    //   the APA.  The rank passed into this function
    //   is the larger of the left and right ranks,
    //   which for the above example, is wrong.

    // Split cases based upon the arg's NELM
    if (aplNELMLft NE 1)
    {
        *lphGlbRes = CopyArray_EM (hGlbLft, TRUE, lptkFunc);
        aplRankRes = aplRankLft;
    } else
    {
        *lphGlbRes = CopyArray_EM (hGlbRht, TRUE, lptkFunc);
        aplRankRes = aplRankRht;
    } // End IF/ELSE

    if (!*lphGlbRes)
    {
        ErrorMessageIndirectToken (ERRMSG_WS_FULL APPEND_NAME,
                                   lptkFunc);
        return FALSE;
    } // End IF

    // Lock the memory to get a ptr to it
    *lplpMemRes = MyGlobalLock (*lphGlbRes);

    // Skip over the header and dimensions to the data
    *lplpMemRes = VarArrayBaseToData (*lplpMemRes, aplRankRes);

#define lpAPA       ((LPAPLAPA) *lplpMemRes)

    // Add in the singleton's value to the result offset
    lpAPA->Off += aplInteger;

#undef  lpAPA

    // Fill in the result token
    if (lpYYRes)
    {
        lpYYRes->tkToken.tkFlags.TknType   = TKT_VARARRAY;
////    lpYYRes->tkToken.tkFlags.ImmType   = 0;
////    lpYYRes->tkToken.tkFlags.NoDisplay = 0;
////    lpYYRes->tkToken.tkFlags.Color     =
        lpYYRes->tkToken.tkData.tkGlbData  = MakeGlbTypeGlb (*lphGlbRes);
    } // End IF

    DBGEXIT;

    return TRUE;
} // End PrimFnDydPlusAPA_EM
#undef APPEND_NAME


//***************************************************************************
//  PrimFnDydPlusSimpSimp_EM
//
//  Dyadic plus, left simple, right simple
//***************************************************************************

#ifdef DEBUG
#define APPEND_NAME     L" -- PrimFnDydPlusSimpSimp_EM"
#else
#define APPEND_NAME
#endif

BOOL PrimFnDydPlusSimpSimp_EM
    (LPYYSTYPE lpYYRes,

     LPTOKEN   lptkLftArg,
     LPTOKEN   lptkFunc,
     LPTOKEN   lptkRhtArg,

     HGLOBAL   hGlbLft,
     HGLOBAL   hGlbRht,
     HGLOBAL  *lphGlbRes,

     LPVOID    lpMemLft,
     LPVOID    lpMemRht,
     LPVOID    lpMemRes,

     LPAPLINT  lpMemAxisHead,
     LPAPLINT  lpMemAxisTail,

     APLRANK   aplRankLft,
     APLRANK   aplRankRht,
     APLRANK   aplRankRes,

     APLSTYPE  cArrTypeLft,
     APLSTYPE  cArrTypeRht,
     APLSTYPE  cArrTypeRes,

     APLNELM   aplNELMLft,
     APLNELM   aplNELMRht,
     APLNELM   aplNELMRes,
     APLNELM   aplNELMAxis)

{
    BOOL       bRet = TRUE;
    APLINT     aplIntegerLft,
               aplIntegerRht;
    APLFLOAT   aplFloatLft,
               aplFloatRht;
    LPAPLINT   lpMemWVec = NULL,
               lpMemOdo = NULL;
    HGLOBAL    hGlbWVec = NULL,
               hGlbOdo = NULL;
    APLINT     uArg,
               uLft,
               uRht,
               uRes;
    LPAPLDIM   lpMemDimArg,
               lpMemDimRes;
    APLINT     apaOffLft,
               apaMulLft,
               apaOffRht,
               apaMulRht;
    UINT       uBitIndex;
    APLINTSIGN iRht;

    DBGENTER;

    //***************************************************************
    // Both arguments are simple
    //***************************************************************

    if (aplNELMLft EQ 1
     && aplNELMRht EQ 1)
    {
        //***************************************************************
        // Both args are singletons
        //***************************************************************

        // Axis may be anything

        // If it's a scalar, ...
        if (aplRankRes EQ 0)
        {
            UINT     immType;

            // Get the immediate type for the token
            immType = TranslateArrayTypeToImmType (cArrTypeRes);

            Assert (IMMTYPE_BOOL  EQ immType
                 || IMMTYPE_INT   EQ immType
                 || IMMTYPE_FLOAT EQ immType);

            // Get the respective first values
            FirstValue (lptkLftArg, &aplIntegerLft, &aplFloatLft, NULL, NULL, NULL);
            FirstValue (lptkRhtArg, &aplIntegerRht, &aplFloatRht, NULL, NULL, NULL);

            // Fill in the result token
            lpYYRes->tkToken.tkFlags.TknType   = TKT_VARIMMED;
            lpYYRes->tkToken.tkFlags.ImmType   = immType;
////        lpYYRes->tkToken.tkFlags.NoDisplay = 0;
////        lpYYRes->tkToken.tkFlags.Color     =
            if (immType EQ IMMTYPE_FLOAT)
                lpYYRes->tkToken.tkData.tkFloat    = aplFloatLft   + aplFloatRht;
            else
                lpYYRes->tkToken.tkData.tkInteger  = aplIntegerLft + aplIntegerRht;
        } else
        // It's a singleton array
        {
            // Skip over the header and dimensions to the data
            lpMemRes = VarArrayBaseToData (lpMemRes, aplRankRes);

            // Get the respective values
            FirstValue (lptkLftArg, &aplIntegerLft, &aplFloatLft, NULL, NULL, NULL);
            FirstValue (lptkRhtArg, &aplIntegerRht, &aplFloatRht, NULL, NULL, NULL);

            if (cArrTypeRes EQ ARRAY_FLOAT)
                *((LPAPLFLOAT) lpMemRes) = aplFloatLft   + aplFloatRht;
            else
                *((LPAPLINT)   lpMemRes) = aplIntegerLft + aplIntegerRht;

            // Fill in the result token
            lpYYRes->tkToken.tkFlags.TknType   = TKT_VARARRAY;
////        lpYYRes->tkToken.tkFlags.ImmType   = 0;
////        lpYYRes->tkToken.tkFlags.NoDisplay = 0;
////        lpYYRes->tkToken.tkFlags.Color     =
            lpYYRes->tkToken.tkData.tkGlbData  = MakeGlbTypeGlb (*lphGlbRes);
        } // End IF

        // Finish with common code
        lpYYRes->tkToken.tkCharIndex       = lptkFunc->tkCharIndex;
    } else
    if (aplNELMLft EQ 1
     || aplNELMRht EQ 1)
    {
        //***************************************************************
        // One of the args is a singleton, the other not
        //***************************************************************

        // Axis may be anything

        // Copy the ptr to the non-singleton argument
        if (aplNELMLft NE 1)
            lpMemDimArg = lpMemLft;
        else
            lpMemDimArg = lpMemRht;

        // Skip over the header and dimensions to the data
        lpMemRes    = VarArrayBaseToData (lpMemRes,    aplRankRes);
        lpMemDimArg = VarArrayBaseToData (lpMemDimArg, aplRankRes);

#define lpHeader    ((LPAPLAPA) lpMemDimArg)

        // In case the non-singleton argument is an APA
        apaOffLft = apaOffRht = lpHeader->Off;
        apaMulLft = apaMulRht = lpHeader->Mul;
////////apaLenLft = apaLenRht = lpHeader->Len;

#undef  lpHeader

        // Get the value of the singleton
        if (aplNELMLft EQ 1)
            FirstValue (lptkLftArg, &aplIntegerLft, &aplFloatLft, NULL, NULL, NULL);
        else
            FirstValue (lptkRhtArg, &aplIntegerRht, &aplFloatRht, NULL, NULL, NULL);

        // In case the non-singleton argument is Boolean
        uBitIndex = 0;

        // Loop through the data creating the result
        for (uRes = 0; uRes < aplNELMRes; uRes++)
        if (aplNELMLft NE 1)
            switch (cArrTypeRes)
            {
                case ARRAY_INT:
                    switch (cArrTypeLft)
                    {
                        case ARRAY_BOOL:        // Res = INT, Lft = BOOL
                            *((LPAPLINT)   lpMemRes)++ = (BIT0 & ((*(LPAPLBOOL) lpMemDimArg) >> uBitIndex++))
                                                       + aplIntegerRht;
                            // Check for end-of-byte
                            if (uBitIndex EQ NBIB)
                            {
                                uBitIndex = 0;              // Start over
                                ((LPAPLBOOL) lpMemDimArg)++;   // Skip to next byte
                            } // End IF

                            break;

                        case ARRAY_INT:         // Res = INT, Lft = INT
                            *((LPAPLINT)   lpMemRes)++ = *((LPAPLINT) lpMemDimArg)++
                                                       + aplIntegerRht;
                            break;

////////////////////////case ARRAY_FLOAT:       // Res = INT, Lft = FLOAT (Can't happen)
////////////////////////    *((LPAPLINT)   lpMemRes)++ = *((LPAPLFLOAT) lpMemDimArg)++
////////////////////////                               + aplIntegerRht;
////////////////////////    break;

                        case ARRAY_APA:         // Res = INT, Lft = APA
                            *((LPAPLINT)   lpMemRes)++ = apaOffLft + apaMulLft * uRes
                                                       + aplIntegerRht;
                            break;

                        defstop
                            break;
                    } // End SWITCH

                    break;

                case ARRAY_FLOAT:
                    switch (cArrTypeLft)
                    {
                        case ARRAY_BOOL:        // Res = FLOAT, Lft = BOOL
                            *((LPAPLFLOAT) lpMemRes)++ = (BIT0 & ((*(LPAPLBOOL) lpMemDimArg) >> uBitIndex++))
                                                       + aplFloatRht;
                            // Check for end-of-byte
                            if (uBitIndex EQ NBIB)
                            {
                                uBitIndex = 0;              // Start over
                                ((LPAPLBOOL) lpMemDimArg)++;   // Skip to next byte
                            } // End IF

                            break;

                        case ARRAY_INT:         // Res = FLOAT, Lft = INT
                            *((LPAPLFLOAT) lpMemRes)++ = ((APLINTSIGN) *((LPAPLINT) lpMemDimArg)++)
                                                       + aplFloatRht;
                            break;

                        case ARRAY_FLOAT:       // Res = FLOAT, Lft = FLOAT
                            *((LPAPLFLOAT) lpMemRes)++ = *((LPAPLFLOAT) lpMemDimArg)++
                                                       + aplFloatRht;
                            break;

                        case ARRAY_APA:         // Res = FLOAT, Lft = APA
                            *((LPAPLFLOAT) lpMemRes)++ = ((APLINTSIGN) (apaOffLft + apaMulLft * uRes))
                                                       + aplFloatRht;
                            break;

                        defstop
                            break;
                    } // End SWITCH

                    break;

                defstop
                    break;
            } // End SWITCH
        else
            switch (cArrTypeRes)
            {
                case ARRAY_INT:
                    switch (cArrTypeRht)
                    {
                        case ARRAY_BOOL:        // Res = INT, Rht = BOOL
                            *((LPAPLINT)   lpMemRes)++ = aplIntegerLft
                                                       + (BIT0 & ((*(LPAPLBOOL) lpMemDimArg) >> uBitIndex++));
                            // Check for end-of-byte
                            if (uBitIndex EQ NBIB)
                            {
                                uBitIndex = 0;              // Start over
                                ((LPAPLBOOL) lpMemDimArg)++;   // Skip to next byte
                            } // End IF

                            break;

                        case ARRAY_INT:         // Res = INT, Rht = INT
                            *((LPAPLINT)   lpMemRes)++ = aplIntegerLft
                                                       + *((LPAPLINT) lpMemDimArg)++;
                            break;

////////////////////////case ARRAY_FLOAT:       // Res = INT, Rht = FLOAT (Can't happen)
////////////////////////    *((LPAPLINT)   lpMemRes)++ = aplIntegerLft
////////////////////////                               + *((LPAPLFLOAT) lpMemDimArg)++;
////////////////////////    break;

                        case ARRAY_APA:         // Res = INT, Rht = APA
                            *((LPAPLINT)   lpMemRes)++ = aplIntegerLft
                                                       + apaOffRht + apaMulRht * uRes;
                            break;

                        defstop
                            break;
                    } // End SWITCH

                    break;

                case ARRAY_FLOAT:
                    switch (cArrTypeRht)
                    {
                        case ARRAY_BOOL:        // Res = FLOAT, Rht = BOOL
                            *((LPAPLFLOAT) lpMemRes)++ = aplFloatLft
                                                       + (BIT0 & ((*(LPAPLBOOL) lpMemDimArg) >> uBitIndex++));
                            // Check for end-of-byte
                            if (uBitIndex EQ NBIB)
                            {
                                uBitIndex = 0;              // Start over
                                ((LPAPLBOOL) lpMemDimArg)++;   // Skip to next byte
                            } // End IF

                            break;

                        case ARRAY_INT:         // Res = FLOAT, Rht = INT
                            *((LPAPLFLOAT) lpMemRes)++ = aplFloatLft
                                                       + (APLINTSIGN) *((LPAPLINT) lpMemDimArg)++;
                            break;

                        case ARRAY_FLOAT:       // Res = FLOAT, Rht = FLOAT
                            *((LPAPLFLOAT) lpMemRes)++ = aplFloatLft
                                                       + *((LPAPLFLOAT) lpMemDimArg)++;
                            break;

                        case ARRAY_APA:         // Res = FLOAT, Rht = APA
                            *((LPAPLFLOAT) lpMemRes)++ = aplFloatLft
                                                       + (APLINTSIGN) (apaOffRht + apaMulRht * uRes);
                            break;

                        defstop
                            break;
                    } // End SWITCH

                    break;

                defstop
                    break;
            } // End SWITCH

        // Fill in the result token
        lpYYRes->tkToken.tkFlags.TknType   = TKT_VARARRAY;
////////lpYYRes->tkToken.tkFlags.ImmType   = 0;
////////lpYYRes->tkToken.tkFlags.NoDisplay = 0;
////////lpYYRes->tkToken.tkFlags.Color     =
        lpYYRes->tkToken.tkData.tkGlbData  = MakeGlbTypeGlb (*lphGlbRes);
        lpYYRes->tkToken.tkCharIndex       = lptkFunc->tkCharIndex;
    } else
    {
        //***************************************************************
        // Neither arg is a singleton, but both are simple
        //***************************************************************

        // Axis is significant (if present)

        // Skip over the header to the dimensions
        lpMemDimRes = VarArrayBaseToDim (lpMemRes);

        // Skip over the header and dimensions to the data
        lpMemRes = VarArrayBaseToData (lpMemRes, aplRankRes);
        lpMemLft = VarArrayBaseToData (lpMemLft, aplRankLft);
        lpMemRht = VarArrayBaseToData (lpMemRht, aplRankRht);

#define lpHeader    ((LPAPLAPA) lpMemLft)

        // In case the left argument is an APA
        apaOffLft = lpHeader->Off;
        apaMulLft = lpHeader->Mul;
////////apaLenLft = lpHeader->Len;

#undef  lpHeader

#define lpHeader    ((LPAPLAPA) lpMemRht)

        // In case the right argument is an APA
        apaOffRht = lpHeader->Off;
        apaMulRht = lpHeader->Mul;
////////apaLenRht = lpHeader->Len;

#undef  lpHeader

        // Fill in the data
        if (lpMemAxisHead && aplNELMAxis NE aplRankRes)
        {
            //***************************************************************
            // Allocate space for the weighting vector which is
            //
            //   {times}{backscan}1{drop}({rho}R)[Cx,Ax],1
            //
            //   where Ax contains the specified axes, and
            //   Cx contains the remaining axes
            // N.B.  Conversion from APLINT to UINT.
            //***************************************************************
            hGlbWVec = DbgGlobalAlloc (GHND, (UINT) (aplRankRes * sizeof (APLINT)));
            if (!hGlbWVec)
            {
                ErrorMessageIndirectToken (ERRMSG_WS_FULL APPEND_NAME,
                                           lptkFunc);
                goto ERROR_EXIT;
            } // End IF

            // Lock the memory to get a ptr to it
            lpMemWVec = MyGlobalLock (hGlbWVec);

            // Loop through the dimensions of the result in reverse
            //   order {backscan} and compute the cumulative product
            //   (weighting vector).
            // Note we use a signed index variable because we're
            //   walking backwards and the test against zero must be
            //   made as a signed variable.
            for (uRes = 1, iRht = aplRankRes - 1; iRht >= 0; iRht--)
            {
                lpMemWVec[iRht] = uRes;
                uRes *= lpMemDimRes[lpMemAxisHead[iRht]];
            } // End FOR

            //***************************************************************
            // Allocate space for the odometer array, one value per dimension
            //   in the right arg, with values initially all zero (thanks to GHND).
            // N.B.  Conversion from APLINT to UINT.
            //***************************************************************
            hGlbOdo = DbgGlobalAlloc (GHND, (UINT) (aplRankRes * sizeof (APLINT)));
            if (!hGlbOdo)
            {
                ErrorMessageIndirectToken (ERRMSG_WS_FULL APPEND_NAME,
                                           lptkFunc);
                goto ERROR_EXIT;
            } // End IF

            // Lock the global memory to get a ptr to it
            lpMemOdo = MyGlobalLock (hGlbOdo);

            // Loop through the result
            for (uRes = 0; uRes < aplNELMRes; uRes++)
            {
                // Loop through the odometer values accumulating
                //   the weighted sum
                for (uArg = 0, uRht = aplRankRes - aplNELMAxis; uRht < aplRankRes; uRht++)
                    uArg += lpMemOdo[lpMemAxisHead[uRht]] * lpMemWVec[uRht];

                // Increment the odometer in lpMemOdo subject to
                //   the values in lpMemDimRes
                IncrOdometer (lpMemOdo, lpMemDimRes, NULL, aplRankRes);

                // Use the just computed index for the argument
                //   with the smaller rank
                if (aplRankLft < aplRankRht)
                {
                    uLft = uArg;
                    uRht = uRes;
                } else
                {
                    uRht = uArg;
                    uLft = uRes;
                } // End IF/ELSE

                // Split cases based upon the result storage type
                switch (cArrTypeRes)
                {
                    case ARRAY_INT:
                        *((LPAPLINT)   lpMemRes)++ = GetNextInteger (lpMemLft, cArrTypeLft, uLft, apaOffLft, apaMulLft)
                                                   + GetNextInteger (lpMemRht, cArrTypeRht, uRht, apaOffRht, apaMulRht);
                        break;

                    case ARRAY_FLOAT:
                        *((LPAPLFLOAT) lpMemRes)++ = GetNextFloat   (lpMemLft, cArrTypeLft, uLft, apaOffLft, apaMulLft)
                                                   + GetNextFloat   (lpMemRht, cArrTypeRht, uRht, apaOffRht, apaMulRht);
                        break;

                    defstop
                        break;
                } // End SWITCH
            } // End FOR
        } else
        {
            // Split cases based upon the result storage type
            switch (cArrTypeRes)
            {
                case ARRAY_INT:
                    for (uRes = 0; uRes < aplNELMRes; uRes++)
                        *((LPAPLINT)   lpMemRes)++ = GetNextInteger (lpMemLft, cArrTypeLft, uRes, apaOffLft, apaMulLft)
                                                   + GetNextInteger (lpMemRht, cArrTypeRht, uRes, apaOffRht, apaMulRht);
                    break;

                case ARRAY_FLOAT:
                    for (uRes = 0; uRes < aplNELMRes; uRes++)
                        *((LPAPLFLOAT) lpMemRes)++ = GetNextFloat   (lpMemLft, cArrTypeLft, uRes, apaOffLft, apaMulLft)
                                                   + GetNextFloat   (lpMemRht, cArrTypeRht, uRes, apaOffRht, apaMulRht);
                    break;

                defstop
                    break;
            } // End SWITCH
        } // End IF/ELSE

        // Fill in the result token
        lpYYRes->tkToken.tkFlags.TknType   = TKT_VARARRAY;
////////lpYYRes->tkToken.tkFlags.ImmType   = 0;
////////lpYYRes->tkToken.tkFlags.NoDisplay = 0;
////////lpYYRes->tkToken.tkFlags.Color     =
        lpYYRes->tkToken.tkData.tkGlbData  = MakeGlbTypeGlb (*lphGlbRes);
        lpYYRes->tkToken.tkCharIndex       = lptkFunc->tkCharIndex;
    } // End IF/ELSE/...

ERROR_EXIT:
    if (hGlbOdo && lpMemOdo)
    {
        // We no longer need this ptr
        MyGlobalUnlock (hGlbOdo); lpMemOdo = NULL;
    } // End IF

    if (hGlbWVec && lpMemWVec)
    {
        // We no longer need this ptr
        MyGlobalUnlock (hGlbWVec); lpMemWVec = NULL;
    } // End IF

    if (hGlbWVec)
    {
        // We no longer need this storage
        DbgGlobalFree (hGlbWVec); hGlbWVec = NULL;
    } // End IF

    if (hGlbOdo)
    {
        // We no longer need this storage
        DbgGlobalFree (hGlbOdo); hGlbOdo = NULL;
    } // End IF

    DBGEXIT;

    return bRet;
} // End PrimFnDydPlusSimpSimp_EM
#undef  APPEND_NAME


//***************************************************************************
//  End of File: pf_plus.c
//***************************************************************************
